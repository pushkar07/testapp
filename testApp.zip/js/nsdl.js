
var uat = "https://121.240.225.119/SpMobileWeb/Entry.do?";//UAT
var staging = "https://121.240.225.104/SpMobileWeb/Entry.do?";//staging
var production = "https://Qfi.nsdl.com/SpMobileWeb/Entry.do?"; //Production
var server_url = staging;
var db_Exp;var db_Skip;
/**************************Get device UUID*******************/
var ios_uuid;var VersionNumber;
function onDeviceReady() {
    ios_uuid = device.uuid;
    localStorage.setItem('iosUuid', JSON.stringify(ios_uuid));
    cordova.getAppVersion(function (version) {
                          VersionNumber = version;
                          $('#versionNo').html("Ver "+version);
                          localStorage.setItem('VersionNumber', JSON.stringify(VersionNumber));
                          var base_url = server_url+"mobDeviceOS=IOS&mobAppVersion="+VersionNumber+"&imeiNumber="+ios_uuid+"&mobOSVersion=6.0&mobDeviceUuId="+ios_uuid+"";
                          
                          localStorage.setItem('base_url', JSON.stringify(base_url));
                          });
    
}
/**************************************************************/

/********************************************upgrade skip count**********************/


function onConfirmUpgrade(buttonIndexupg){
    if(buttonIndexupg == 1){
        
        SkipUpdate();
    }
    else{
        $("#backg").css("display", "none");
        window.open(JSON.parse(localStorage.getItem('appUpdateUrlstore')), '_system');
        $("#backg").css("display", "none");
    }
}

function SkipUpdate(){
    var base_url = JSON.parse(localStorage.getItem('base_url'));
    var userid = $("#uid").val();
    var password = $("#pass").val();
    var result_login = JSON.parse(localStorage.getItem('result_login'));
    var temp_dpid1 = result_login.dpId; var temp_clientId1 = result_login.clientId;var temp_userId1 = result_login.userId;var temp_user_name = result_login.userName;
    var ccrflag;var mob_flag = result_login.mobileFlag;
    var userType = result_login.userType;
    var d_time = result_login.loginTime;
    isin_time = d_time.split(' ');
    if(!result_login.lastLogin)
    {
        var set_tempdt = result_login.loginTime;
        temp_last_login = set_tempdt;
        
    }
    else
    {
        temp_last_login = result_login.lastLogin;
    }
    var cYear = isin_time[2].split(',');
    lYear = temp_last_login.split(',');
    LYearDay = lYear[0].split(' ');
    var temp_current_dt = isin_time[0]+' '+isin_time[1]+', '+cYear[1];
    localStorage.setItem('temp_dpid1', JSON.stringify(temp_dpid1));
    localStorage.setItem('temp_clientId1', JSON.stringify(temp_clientId1));
    localStorage.setItem('temp_userId1', JSON.stringify(temp_userId1));
    localStorage.setItem('temp_user_name', JSON.stringify(temp_user_name));
    localStorage.setItem('temp_last_login', JSON.stringify( LYearDay[0]+" "+LYearDay[1]+", "+lYear[1] ) );
    localStorage.setItem('temp_current_dt', JSON.stringify(temp_current_dt));
    if(!result_login.ccrFlag)
    {
        ccrflag = "N";
    }
    else{
        ccrflag = result_login.ccrFlag;
    }
    
    localStorage.setItem('ccrflag', JSON.stringify(ccrflag));
    localStorage.setItem('mob_flag', JSON.stringify(mob_flag));
    localStorage.setItem('userType', JSON.stringify(userType));
    var user_id = JSON.parse(localStorage.getItem('temp_userId1'));
    var dp_id = JSON.parse(localStorage.getItem('temp_dpid1'));
    var client_id = JSON.parse(localStorage.getItem('temp_clientId1'));
    localStorage.setItem('temp_password', JSON.stringify(password));
    
    var PaidInd;
    var ccr_f = JSON.parse(localStorage.getItem('ccrflag'));
    var mob_f = JSON.parse(localStorage.getItem('mob_flag'));
    var userType = JSON.parse(localStorage.getItem('userType'));
    if(ccr_f == "Y" && mob_f == "MOB" && userType == "INV")
    {
        console.log("e-dis enable..");
        var surl_edis = base_url+'&userId='+user_id+'&functionId=1008&dpId='+dp_id+'&clientId='+client_id+'';
        
        var data_edis = global_ajax(surl_edis);
        console.log(data_edis);
        var edis_data = data_edis;
        localStorage.setItem('edis_data', JSON.stringify(edis_data));
        var result_temp = $.parseJSON(data_edis);
        var edis_count_temp = result_temp.pendingInstructionList;
        if(result_temp.status == "S")
        {
            edis_length = edis_count_temp.length;
            localStorage.setItem('edis_length', JSON.stringify(edis_length));
        }
        else
        {
            edis_length = "0";
            localStorage.setItem('edis_length', JSON.stringify(edis_length));
        }
    }
    else{
        edis_length = "0";
        localStorage.setItem('edis_length', JSON.stringify(edis_length));
    }
    if(!result_login.PaidInd)
    {
        console.log("free user..");
        PaidInd = "NP";
        localStorage.setItem('PaidInd', JSON.stringify(PaidInd));
        var surl_soh = base_url+'&userId='+user_id+'&functionId=1001&dpId='+dp_id+'&clientId='+client_id+'';
        var data_soh = FreeUserSoh(surl_soh);
        localStorage.setItem('soh_data', JSON.stringify(data_soh));
        window.plugins.toast.show('Logged in successfully.', 'long', 'bottom');
        window.open("equity.html",'_self',false);
        
    }
    else
    {
        //PaidInd = "YP";
        var paidexpiryDt = result_login.PaidExpiryDate;
        localStorage.setItem('RealTmpaidexpiryDt', JSON.stringify(paidexpiryDt));
        var temp_paidexpiryDt = paidexpiryDt.split(" ");
        localStorage.setItem('TpaidexpiryDt', JSON.stringify(temp_paidexpiryDt[0]));
        var paidExpiry = JSON.parse(localStorage.getItem('TpaidexpiryDt'));
        var temp_paidExpiry = paidExpiry.split("-");
        var today, someday, text;
        today = new Date();
        var tempTodayDate = (today.toString()).split(" ");
        someday = new Date(temp_paidExpiry[0], temp_paidExpiry[1] - 1, temp_paidExpiry[2]);
        expDateDbCall();
        if (someday > today) {
            var expiredPortfolio = "NExP";console.log("NExP");
            localStorage.setItem('expiredPortfolio', JSON.stringify(expiredPortfolio));
            window.plugins.toast.show('Logged in successfully.', 'long', 'bottom');
            portfolio_refresh();
        } else {
            console.log("Paid portfolio expired.");
            var expiredPortfolio = "ExP";console.log("ExP");
            localStorage.setItem('expiredPortfolio', JSON.stringify(expiredPortfolio));
            var surl_soh = base_url+'&userId='+user_id+'&functionId=1001&dpId='+dp_id+'&clientId='+client_id+'';
            var data_soh = FreeUserSoh(surl_soh);
            localStorage.setItem('soh_data', JSON.stringify(data_soh));
            window.plugins.toast.show('Logged in successfully.', 'long', 'bottom');
            window.open("equity.html",'_self',false);
        }
        
    }
}


/********************************************end upgrade skip count**********************/

/********************************************logout**********************/
function onConfirm(buttonIndex) {
    $('.slide-in').toggleClass('on');
    $('#main_wrapper').toggleClass('on');
    outIn = 'in';
    
    if(buttonIndex == 1){
        return false;
    }
    else{
        var base_url = JSON.parse(localStorage.getItem('base_url'));
        $("#backg").css("display", "block");
        setTimeout(function(){
                   var user_id = JSON.parse(localStorage.getItem('temp_userId'));
                   var dp_id = JSON.parse(localStorage.getItem('temp_dpid'));
                   var client_id = JSON.parse(localStorage.getItem('temp_clientId'));
                   var logoutApp = base_url+'&userId='+user_id+'&functionId=9999&dpId='+dp_id+'&clientId='+client_id+'';
                   var data = global_ajax(logoutApp);
                   console.log(data);
                   var result = $.parseJSON(data);console.log(result.status);
                   if(result.status == 'F'){
                   localStorage.clear();
                   onDeviceReady();
                   window.plugins.toast.show(result.message, 'long', 'bottom');
                   cordova.getAppVersion(function (version) {
                                         VersionNumber = version;
                                         localStorage.setItem('VersionNumber', JSON.stringify(VersionNumber));
                                         });
                   window.open("index.html",'_self',false);
                   $("#backg").css("display", "none");
                   
                   }
                   else{
                   localStorage.clear();
                   onDeviceReady();
                   window.plugins.toast.show(result.message, 'long', 'bottom');
                   cordova.getAppVersion(function (version) {
                                         VersionNumber = version;
                                         localStorage.setItem('VersionNumber', JSON.stringify(VersionNumber));
                                         });
                   window.open("index.html",'_self',false);
                   $("#backg").css("display", "none");
                   }
                   },300);
        
    }
}
/********************************************end logout**********************/


$(document).on('blur', 'input, textarea', function() {
               setTimeout(function() {
                          window.scrollTo(document.body.scrollLeft, document.body.scrollTop);
                          }, 0);
               });
$(document).ready(function () {
                  
                  // .click(function(){
                  //.on("click touchstart",function() {
                  /********************************************logged in**********************/
                  $("#login").click(function(){
                                    ios_uuid = device.uuid;var VersionNumber;
                                    localStorage.setItem('iosUuid', JSON.stringify(ios_uuid));
                                    cordova.getAppVersion(function (version) {
                                                          VersionNumber = version;
                                                          localStorage.setItem('VersionNumber', JSON.stringify(VersionNumber));
                                                          
                                                          });
                                    var base_url = server_url+"mobDeviceOS=IOS&mobAppVersion="+JSON.parse(localStorage.getItem('VersionNumber'))+"&imeiNumber="+ios_uuid+"&mobOSVersion=6.0&mobDeviceUuId="+ios_uuid+"";
                                    localStorage.setItem('base_url', JSON.stringify(base_url));
                                    //connection();
                                    var edis_length;var temp_last_login;var temp_ccrf;
                                    var userid = $("#uid").val();
                                    var password = $("#pass").val();
                                    if(userid == "")
                                    {
                                    swal({
                                         title: " ",
                                         text: "Please enter User ID"
                                         },
                                         function(){
                                         return false;
                                         });
                                    
                                    }
                                    else if(/\s/g.test(userid))
                                    {
                                    swal({
                                         title: " ",
                                         text: "User ID should not contain space."
                                         },
                                         function(){
                                         return false;
                                         });
                                    
                                    }
                                    else if(userid.length < 3)
                                    {
                                    swal({
                                         title: " ",
                                         text: "User ID length must be minimum 3 characters."
                                         },
                                         function(){
                                         return false;
                                         });
                                    }
                                    
                                    else if(password == "")
                                    {
                                    swal({
                                         title: " ",
                                         text: "Please enter Password."
                                         },
                                         function(){
                                         return false;
                                         });
                                    }
                                    
                                    else if(password.length < 8)
                                    {
                                    swal({
                                         title: " ",
                                         text: "Password length must be minimum 8 characters."
                                         },
                                         function(){
                                         document.getElementById("pass").value = "";
                                         return false;
                                         });
                                    }
                                    else if(/\s/g.test(password))
                                    {
                                    
                                    swal({
                                         title: " ",
                                         text: "Password should not contain spaces."
                                         },
                                         function(){
                                         document.getElementById("pass").value = "";
                                         return false;
                                         });
                                    }
                                    else if(/^[a-zA-Z]*$/.test(password) == true)
                                    {
                                    swal({
                                         title: " ",
                                         text: "Password must contain atleast one alphabet and two numerics."
                                         },
                                         function(){
                                         document.getElementById("pass").value = "";
                                         return false;
                                         });
                                    }
                                    else
                                    {
                                    var surl_login = base_url +'&functionId=1000&userId='+userid+'&passWord='+encodeURIComponent($("#pass").val())+'';
                                    $("#backg").css("display", "block");
                                    setTimeout(function(){
                                               var data_login = global_ajax(surl_login);
                                               var result_login = $.parseJSON(data_login);console.log(result_login);
                                               localStorage.setItem('result_login', JSON.stringify(result_login));
                                               
                                               if(result_login.status == "F" && result_login.errorCode == "1026")
                                               {
                                               
                                               $("#backg").css("display", "none");
                                               swal({
                                                    title: " ",
                                                    text: result_login.errorDescription
                                                    },
                                                    function(){
                                                    window.open("forgot_password.html",'_self',false);
                                                    });
                                               
                                               }
                                               else if(result_login.status == "F" && result_login.errorCode == "1014"){
                                               localStorage.setItem('exUserId', JSON.stringify(result_login.userId));
                                               localStorage.setItem('exdpId', JSON.stringify(result_login.dpId));
                                               localStorage.setItem('exclientId', JSON.stringify(result_login.clientId));
                                               swal({
                                                    title: " ",
                                                    text: result_login.errorDescription
                                                    },
                                                    function(){
                                                    window.open("passwordExpired.html",'_self',false);
                                                    });
                                               }
                                               else if(result_login.status == "F")
                                               {
                                               $("#backg").css("display", "none");
                                               swal({
                                                    title: " ",
                                                    text: result_login.errorDescription
                                                    },
                                                    function(){
                                                    document.getElementById("pass").value = "";
                                                    return false;
                                                    });
                                               
                                               }
                                               
                                               else if(result_login.errorCode == "1051"){
                                               localStorage.setItem('updateVersion',JSON.stringify(result_login.errorDescription));
                                               localStorage.setItem('appUpdateUrlstore', JSON.stringify(result_login.appUpdateUrl));
                                               navigator.notification.confirm(JSON.parse(localStorage.getItem('updateVersion')),onConfirmUpgrade," ",['Skip','Update']);
                                               
                                               }
                                               else
                                               {
                                               SkipUpdate();
                                               }
                                               },200);
                                    
                                    }
                                    
                                    });
                  /********************************************END logged in**********************/
                  
                  /********************************************Compose Mail**********************/
                  $("#mailcomposer").click(function(){
                                           cordova.plugins.email.isAvailable(
                                                                             function (isAvailable) {
                                                                             if(isAvailable == false)
                                                                             {
                                                                             window.plugins.socialsharing.share('Feedback on NSDL for IOS build');
                                                                             }
                                                                             else
                                                                             {
                                                                             var deviceName = device.model;
                                                                             var deviceVersion = device.version;
                                                                             cordova.plugins.email.open({
                                                                                                        to:      'mobileappfeedback@nsdl.co.in',
                                                                                                        //subject: 'Greetings',
                                                                                                        body:    'Feedback on NSDL for IOS build <br /><br /> OS Version : '+deviceVersion+' <br /> Device model : '+ deviceName,
                                                                                                        isHtml:  true
                                                                                                        });
                                                                             }
                                                                             }
                                                                             );
                                           
                                           
                                           });
                  /********************************************END Compose Mail**********************/
                  
                  /********************************************Edis Refresh**********************/
                  $(".edis_refresh").click(function(){
                                           $("#backg").css("display", "block");
                                           var base_url = JSON.parse(localStorage.getItem('base_url'));
                                           setTimeout(function(){
                                                      var edis_length;
                                                      var user_id = JSON.parse(localStorage.getItem('temp_userId1'));
                                                      var dp_id = JSON.parse(localStorage.getItem('temp_dpid1'));
                                                      var client_id = JSON.parse(localStorage.getItem('temp_clientId1'));
                                                      var surl_edis = base_url+'&userId='+user_id+'&functionId=1008&dpId='+dp_id+'&clientId='+client_id+'';
                                                      var data = global_ajax(surl_edis);
                                                      
                                                      console.log(data);
                                                      var edis_data = data;
                                                      localStorage.setItem('edis_data', JSON.stringify(edis_data));
                                                      var result_temp = $.parseJSON(edis_data);
                                                      var edis_count_temp = result_temp.pendingInstructionList;
                                                      if(result_temp.status == "S")
                                                      {
                                                      edis_length = edis_count_temp.length;
                                                      localStorage.setItem('edis_length', JSON.stringify(edis_length));
                                                      }
                                                      /* else if(result_temp.errorCode == "9998"){
                                                       $(".backg").hide();
                                                       swal("Session Time Out,Please Login again..");
                                                       window.open("index.html",'_self',false);
                                                       
                                                       }*/
                                                      else
                                                      {
                                                      edis_length = "0";
                                                      localStorage.setItem('edis_length', JSON.stringify(edis_length));
                                                      }
                                                      window.open("edis.html","_self",false);
                                                      },100);
                                           
                                           
                                           });
                  /********************************************END Edis Refresh**********************/
                  
                  /********************************************Registration**********************/
                  $("#sign_up").click(function(){
                                      window.open("registration.html",'_self',false);
                                      
                                      });
                  $("#registration").click(function(){
                                           ios_uuid = device.uuid;var VersionNumber;
                                           localStorage.setItem('iosUuid', JSON.stringify(ios_uuid));
                                           cordova.getAppVersion(function (version) {
                                                                 VersionNumber = version;
                                                                 localStorage.setItem('VersionNumber', JSON.stringify(VersionNumber));
                                                                 
                                                                 });
                                           var base_url = server_url+"mobDeviceOS=IOS&mobAppVersion="+JSON.parse(localStorage.getItem('VersionNumber'))+"&imeiNumber="+ios_uuid+"&mobOSVersion=6.0&mobDeviceUuId="+ios_uuid+"";
                                           localStorage.setItem('base_url', JSON.stringify(base_url));
                                           //connection();
                                           var dp_id = $("#dp_idr").val();
                                           var client_id = $("#client_idr").val();
                                           var user_id = $("#user_idr").val();
                                           var user_name = $("#user_namer").val();
                                           var email_id = $("#email_idr").val();
                                           var password = $("#passwordr").val();
                                           var confirm_pass = $("#confirm_passr").val();
                                           var atpos = email_id.indexOf("@");
                                           var dotpos = email_id.lastIndexOf(".");
                                           var base_url = JSON.parse(localStorage.getItem('base_url'));
                                           //var temp_uuid = JSON.parse(localStorage.getItem('ios_uuid'));
                                           if(dp_id == "")
                                           {
                                           swal({
                                                title: " ",
                                                text: "Please enter DP ID"
                                                },
                                                function(){
                                                return false;
                                                });
                                           }
                                           else if(dp_id.length < 8){
                                           swal({
                                                title: " ",
                                                text: "Invalid DP ID."
                                                },
                                                function(){
                                                return false;
                                                });
                                           }
                                           else if( (/[~`!#@$%\^&*+=\-_\[\]\\;,/{}|\\:<>\?]/.test(dp_id) == true) && (/\s/g.test(dp_id)) ){
                                           swal({
                                                title: " ",
                                                text: "DP ID should not contain special characters."
                                                },
                                                function(){
                                                return false;
                                                });
                                           }
                                           else if((/\s/g.test(dp_id)))
                                           {
                                           swal({
                                                title: " ",
                                                text: "DP ID should not contain space."
                                                },
                                                function(){
                                                return false;
                                                });
                                           }
                                           else if(/[~`!#$%\^&*+=\-_\[\]\\;,/{}|\\:<>\?]/.test(dp_id) == true)
                                           {
                                           swal({
                                                title: " ",
                                                text: "Invalid DP ID."
                                                },
                                                function(){
                                                return false;
                                                });
                                           }
                                           
                                           
                                           else if(/^[inIN0-9]*$/.test(dp_id) == false){
                                           swal({
                                                title: " ",
                                                text: "Invalid DP ID."
                                                },
                                                function(){
                                                return false;
                                                });
                                           }
                                           else if(((dp_id.charAt(0)).match(/^[0-9]/))){
                                           swal({
                                                title: " ",
                                                text: "Invalid DP ID."
                                                },
                                                function(){
                                                return false;
                                                });
                                           }
                                           else if(((dp_id.charAt(1)).match(/^[0-9]/))){
                                           swal({
                                                title: " ",
                                                text: "Invalid DP ID."
                                                },
                                                function(){
                                                return false;
                                                });
                                           }
                                           else if(dp_id.length < 3){
                                           swal({
                                                title: " ",
                                                text: "Invalid DP ID."
                                                },
                                                function(){
                                                return false;
                                                });
                                           }
                                           
                                           //client id validation.
                                           else if(client_id == "")
                                           {
                                           swal({
                                                title: " ",
                                                text: "Please enter Client ID."
                                                },
                                                function(){
                                                return false;
                                                });
                                           }
                                           else if(client_id.length < 8)
                                           {
                                           swal({
                                                title: " ",
                                                text: "Invalid Client ID."
                                                },
                                                function(){
                                                return false;
                                                });
                                           }
                                           else if(isNaN(client_id)){
                                           swal({
                                                title: " ",
                                                text: "Invalid Client ID."
                                                },
                                                function(){
                                                return false;
                                                });
                                           }
                                           else if(/\s/g.test(client_id))
                                           {
                                           swal({
                                                title: " ",
                                                text: "Client ID should not contain spaces."
                                                },
                                                function(){
                                                return false;
                                                });
                                           }
                                           //userid verification.
                                           else if(user_id == "")
                                           {
                                           swal({
                                                title: " ",
                                                text: "Please enter User ID"
                                                },
                                                function(){
                                                return false;
                                                });
                                           }
                                           else if(/^[0-9]/.test(user_id) == true)
                                           {
                                           swal({
                                                title: " ",
                                                text: "User ID should start with an alphabet."
                                                },
                                                function(){
                                                return false;
                                                });
                                           }
                                           else if( !((user_id.charAt(0)).match(/^[a-zA-Z0-9_]/) ))
                                           {
                                           swal({
                                                title: " ",
                                                text: "User ID should not start with a special character."
                                                },
                                                function(){
                                                return false;
                                                });
                                           }
                                           
                                           else if(user_id.match(/^\d+$/))
                                           {
                                           swal({
                                                title: " ",
                                                text: "User ID should not contain only numbers"
                                                },
                                                function(){
                                                return false;
                                                });
                                           }
                                           else if(/\s/g.test(user_id))
                                           {
                                           swal({
                                                title: " ",
                                                text: "User ID should not contain space."
                                                },
                                                function(){
                                                return false;
                                                });
                                           }
                                           else if(/^[a-zA-Z0-9_]*$/.test(user_id) == false)
                                           {
                                           swal({
                                                title: " ",
                                                text: "User ID should not contain special characters"
                                                },
                                                function(){
                                                return false;
                                                });
                                           }
                                           else if(user_id.length < 3)
                                           {
                                           swal({
                                                title: " ",
                                                text: "User ID length must be minimum 3 characters"
                                                },
                                                function(){
                                                return false;
                                                });
                                           }
                                           //username validation.
                                           else if(user_name == "")
                                           {
                                           swal({
                                                title: " ",
                                                text: "Please enter User Name"
                                                },
                                                function(){
                                                return false;
                                                });
                                           }
                                           else if(user_name.match(/^\d+$/))
                                           {
                                           swal({
                                                title: " ",
                                                text: "User Name should not contain only numerics."
                                                },
                                                function(){
                                                return false;
                                                });
                                           }
                                           else if(/^[a-zA-Z0-9_'. ']*$/.test(user_name) == false)
                                           {
                                           swal({
                                                title: " ",
                                                text: "User Name should not contain special characters except _ . '."
                                                },
                                                function(){
                                                return false;
                                                });
                                           }
                                           else if(email_id == "")
                                           {
                                           swal({
                                                title: " ",
                                                text: "Please enter Email ID."
                                                },
                                                function(){
                                                return false;
                                                });
                                           }
                                           else if(atpos < 1 || ( dotpos - atpos < 2 ))
                                           {
                                           swal({
                                                title: " ",
                                                text: "Please enter valid Email ID."
                                                },
                                                function(){
                                                return false;
                                                });
                                           }
                                           //password validation.
                                           else if(password == "")
                                           {
                                           setTimeout(function(){
                                                      swal({
                                                           title: " ",
                                                           text: "Please enter Password."
                                                           },
                                                           function(){
                                                           document.getElementById("confirm_passr").value = "";
                                                           return false;
                                                           });
                                                      },1);
                                           }
                                           
                                           else if(password.length < 8)
                                           {
                                           setTimeout(function(){
                                                      swal({
                                                           title: " ",
                                                           text: "Password length must be minimum 8 characters."
                                                           },
                                                           function(){
                                                           document.getElementById("passwordr").value = "";
                                                           document.getElementById("confirm_passr").value = "";
                                                           return false;
                                                           });
                                                      },1);
                                           }
                                           else if( !((password.charAt(0)).match(/^[a-zA-Z0-9]/) ))
                                           {
                                           swal({
                                                title: " ",
                                                text: "Password should not start with a special character."
                                                },
                                                function(){
                                                return false;
                                                });
                                           }
                                           
                                           else if(password.match(/^[a-zA-Z]*$/))
                                           {
                                           setTimeout(function(){
                                                      swal({
                                                           title: " ",
                                                           text: "Password must contain atleast one alphabet and two numerics."
                                                           },
                                                           function(){
                                                           document.getElementById("passwordr").value = "";
                                                           document.getElementById("confirm_passr").value = "";
                                                           return false;
                                                           });
                                                      },1);
                                           }
                                           else if(password.match(/^[0-9]*$/))
                                           {
                                           setTimeout(function(){
                                                      swal({
                                                           title: " ",
                                                           text: "Password must contain atleast one alphabet and two numerics."
                                                           },
                                                           function(){
                                                           document.getElementById("passwordr").value = "";
                                                           document.getElementById("confirm_passr").value = "";
                                                           return false;
                                                           });
                                                      },1);
                                           }
                                           else if(/\s/g.test(password))
                                           {
                                           setTimeout(function(){
                                                      swal({
                                                           title: " ",
                                                           text: "Password should not contain spaces."
                                                           },
                                                           function(){
                                                           document.getElementById("passwordr").value = "";
                                                           document.getElementById("confirm_passr").value = "";
                                                           return false;
                                                           });
                                                      },1);
                                           }
                                           else if(confirm_pass == "")
                                           {
                                           setTimeout(function(){
                                                      swal({
                                                           title: " ",
                                                           text: "Please enter Confirm Password."
                                                           },
                                                           function(){
                                                           return false;
                                                           });
                                                      },1);
                                           }
                                           else if(confirm_pass != password)
                                           {
                                           setTimeout(function(){
                                                      swal({
                                                           title: " ",
                                                           text: "Password and Confirm Password do not match, Please re-enter the password."
                                                           },
                                                           function(){
                                                           document.getElementById("passwordr").value = "";
                                                           document.getElementById("confirm_passr").value = "";
                                                           return false;
                                                           });
                                                      },1);
                                           }
                                           else if (!$("#checkTerms").is(':checked')) {
                                           swal({
                                                title: " ",
                                                text: "Please agree Terms and Conditions."
                                                },
                                                function(){
                                                return false;
                                                });
                                           }
                                           
                                           else
                                           {
                                           
                                           var surl_reg = base_url+'&userId='+user_id+'&functionId=1003&dpId='+dp_id+'&clientId='+client_id+'&emailId='+email_id+'&passWord='+encodeURIComponent($("#passwordr").val())+'&userName='+user_name+'';
                                           $("#backg").css("display", "block");
                                           setTimeout(function(){
                                                      var data = global_ajax(surl_reg);
                                                      var result = $.parseJSON(data);console.log(result.status);
                                                      console.log(data);
                                                      var result = $.parseJSON(data);console.log(result.status);
                                                      var temp_dpid = result.dpId;
                                                      var temp_clientId = result.clientId;
                                                      var temp_userId = result.userId;
                                                      localStorage.setItem('temp_dpid', JSON.stringify(temp_dpid));
                                                      localStorage.setItem('temp_clientId', JSON.stringify(temp_clientId));
                                                      localStorage.setItem('temp_userId', JSON.stringify(temp_userId));
                                                      
                                                      //JSON.parse(localStorage.getItem('contact_no’))
                                                      if(result.status == 'S'){
                                                      swal({
                                                           title: " ",
                                                           text: result.message
                                                           },
                                                           function(){
                                                           localStorage.setItem('RegLogin', JSON.stringify(temp_userId));
                                                           window.open("otp.html",'_self',false);
                                                           });
                                                      
                                                      
                                                      }
                                                      else{
                                                      
                                                      $("#backg").css("display", "none");
                                                      swal({
                                                           title: " ",
                                                           text: result.errorDescription
                                                           },
                                                           function(){
                                                           document.getElementById("passwordr").value = "";
                                                           document.getElementById("confirm_passr").value = "";
                                                           return false;
                                                           });
                                                      }
                                                      },100);
                                           }
                                           //$(".backg").hide();
                                           
                                           });
                  
                  $("#otp_confirm").click(function(){
                                          //$("#backg").css("display", "block");
                                          var otp_ios = $("#otp_ios").val();
                                          var user_id = JSON.parse(localStorage.getItem('temp_userId'));
                                          var dp_id = JSON.parse(localStorage.getItem('temp_dpid'));
                                          var client_id = JSON.parse(localStorage.getItem('temp_clientId'));
                                          var base_url = JSON.parse(localStorage.getItem('base_url'));
                                          var surl_otp = base_url+'&userId='+user_id+'&functionId=1005&dpId='+dp_id+'&clientId='+client_id+'&otp='+otp_ios+'';
                                          if(otp_ios == "")
                                          {
                                          swal({
                                               title: " ",
                                               text: "Please enter OTP"
                                               },
                                               function(){
                                               return false;
                                               });
                                          }
                                          else if(/\s/g.test(otp_ios))
                                          {
                                          swal({
                                               title: " ",
                                               text: "OTP should not contain spaces."
                                               },
                                               function(){
                                               document.getElementById("otp_ios").value = "";
                                               return false;
                                               });
                                          }
                                          else if(isNaN(otp_ios)){
                                          swal({
                                               title: " ",
                                               text: "OTP field should contain only numbers."
                                               },
                                               function(){
                                               document.getElementById("otp_ios").value = "";
                                               return false;
                                               });
                                          
                                          }
                                          else
                                          {
                                          $("#backg").css("display", "block");
                                          setTimeout(function(){
                                                     var data = global_ajax(surl_otp);
                                                     var result = $.parseJSON(data);console.log(result.status);
                                                     console.log(data);
                                                     var result = $.parseJSON(data);console.log(result.status);
                                                     if(result.status == 'F'){
                                                     $("#backg").css("display", "none");
                                                     swal({
                                                          title: " ",
                                                          text: result.errorDescription
                                                          },
                                                          function(){
                                                          document.getElementById("otp_ios").value = "";
                                                          return false;
                                                          });
                                                     }
                                                     
                                                     else{
                                                     swal({
                                                          title: " ",
                                                          text: result.message
                                                          },
                                                          function(){
                                                          localStorage.setItem('RegLogin', JSON.stringify(user_id));
                                                          window.open("index.html",'_self',false);
                                                          });
                                                     }
                                                     
                                                     },100);
                                          
                                          }
                                          
                                          });
                  //otp_resend
                  $("#otp_resend").click(function(){
                                         $("#backg").css("display", "block");
                                         var base_url = JSON.parse(localStorage.getItem('base_url'));
                                         setTimeout(function(){
                                                    var user_id = JSON.parse(localStorage.getItem('temp_userId'));
                                                    var dp_id = JSON.parse(localStorage.getItem('temp_dpid'));
                                                    var client_id = JSON.parse(localStorage.getItem('temp_clientId'));
                                                    var surl_otp_resend = base_url+'&userId='+user_id+'&functionId=1006&dpId='+dp_id+'&clientId='+client_id+'';
                                                    var data = global_ajax(surl_otp_resend);
                                                    console.log(data);
                                                    var result = $.parseJSON(data);console.log(result.status);
                                                    if(result.status == 'F'){
                                                    $("#backg").css("display", "none");
                                                    swal({
                                                         title: " ",
                                                         text: result.errorDescription
                                                         },
                                                         function(){
                                                         document.getElementById("otp_ios").value = "";
                                                         return false;
                                                         });
                                                    }
                                                    else{
                                                    $("#backg").css("display", "none");
                                                    swal({
                                                         title: " ",
                                                         text: result.message
                                                         },
                                                         function(){
                                                         return false;
                                                         });
                                                    }
                                                    },100);
                                         
                                         });
                  
                  $("#term").click(function(){
                                   //window.open("terms_and_condition.html",'_self',false);
                                   $(".black_overlay").show();$(".white_content").show();
                                   });
                  $("#closeTerms").click(function(){
                                         $(".black_overlay").hide();$(".white_content").hide();
                                         });
                  /********************************************END Registration**********************/
                  $("#back_history").click(function(){
                                           $(".overlay_user").hide();
                                           history.go(-1);
                                           });
                  $(".cancelToHome").click(function(){
                                           window.open("index.html",'_self',false);
                                           });
                  
                  $("#forgot_password").click(function(){
                                              window.open("forgot_password.html",'_self',false);
                                              
                                              });
                  //portfolio
                  $("#back_historySOH").click(function(){
                                              hidemenu = "yes";
                                              $(".overlay_user").hide();
                                              history.go(-1);
                                              localStorage.setItem('hidemenu', JSON.stringify(hidemenu));
                                              });
                  //SOH
                  $("#backHistorySOHfree").click(function(){
                                                 FreeUser = "freeUser";
                                                 localStorage.setItem('FreeUser', JSON.stringify(FreeUser));
                                                 $(".overlay_user").hide();
                                                 history.go(-1);
                                                 });
                  
                  //Pass values for forgot password..
                  /********************************************Reset Password**********************/
                  $("#forgot_submit").click(function(){
                                            ios_uuid = device.uuid;var VersionNumber;
                                            localStorage.setItem('iosUuid', JSON.stringify(ios_uuid));
                                            cordova.getAppVersion(function (version) {
                                                                  VersionNumber = version;
                                                                  localStorage.setItem('VersionNumber', JSON.stringify(VersionNumber));
                                                                  
                                                                  });
                                            var base_url = server_url+"mobDeviceOS=IOS&mobAppVersion="+JSON.parse(localStorage.getItem('VersionNumber'))+"&imeiNumber="+ios_uuid+"&mobOSVersion=6.0&mobDeviceUuId="+ios_uuid+"";
                                            localStorage.setItem('base_url', JSON.stringify(base_url));
                                            var userid_c = $("#userid").val();
                                            var dpid_c = $("#dp_id").val();
                                            var clientid_c = $("#client_id").val();
                                            var res = userid_c.toUpperCase();
                                            var base_url = JSON.parse(localStorage.getItem('base_url'));
                                            //DP ID validation.
                                            if(dpid_c == "")
                                            {
                                            swal({
                                                 title: " ",
                                                 text: "Please enter DP ID."
                                                 },
                                                 function(){
                                                 return false;
                                                 });
                                            }
                                            else if(dpid_c.length < 8){
                                            swal({
                                                 title: " ",
                                                 text: "Invalid DP ID."
                                                 },
                                                 function(){
                                                 return false;
                                                 });
                                            }
                                            else if(!dpid_c.charAt(2)){
                                            swal({
                                                 title: " ",
                                                 text: "Invalid DP ID."
                                                 },
                                                 function(){
                                                 return false;
                                                 });
                                            }
                                            else if(isNaN(dpid_c.charAt(2))){
                                            swal({
                                                 title: " ",
                                                 text: "Invalid DP ID."
                                                 },
                                                 function(){
                                                 return false;
                                                 });
                                            }
                                            else if(!isNaN(dpid_c.charAt(0))){
                                            swal({
                                                 title: " ",
                                                 text: "Invalid DP ID."
                                                 },
                                                 function(){
                                                 return false;
                                                 });
                                            }
                                            else if(!isNaN(dpid_c.charAt(1))){
                                            swal({
                                                 title: " ",
                                                 text: "Invalid DP ID."
                                                 },
                                                 function(){
                                                 return false;
                                                 });
                                            }
                                            else if(/\s/g.test(dpid_c))
                                            {
                                            swal({
                                                 title: " ",
                                                 text: "DP ID should not contain special characters."
                                                 },
                                                 function(){
                                                 return false;
                                                 });
                                            }
                                            else if(/^[a-zA-Z0-9 ]*$/.test(dpid_c) == false)
                                            {
                                            swal({
                                                 title: " ",
                                                 text: "DP ID should not contain special characters."
                                                 },
                                                 function(){
                                                 return false;
                                                 });
                                            }
                                            //CLIENT ID validation.
                                            else if(clientid_c == "")
                                            {
                                            swal({
                                                 title: " ",
                                                 text: "Please enter Client ID."
                                                 },
                                                 function(){
                                                 return false;
                                                 });
                                            }
                                            else if(clientid_c.length < 8)
                                            {
                                            swal({
                                                 title: " ",
                                                 text: "Invalid Client ID."
                                                 },
                                                 function(){
                                                 return false;
                                                 });
                                            }
                                            else if(isNaN(clientid_c)){
                                            swal({
                                                 title: " ",
                                                 text: "Invalid Client ID."
                                                 },
                                                 function(){
                                                 return false;
                                                 });
                                            
                                            }
                                            //user id validation.
                                            else if(userid_c == "")
                                            {
                                            swal({
                                                 title: " ",
                                                 text: "Please enter User ID."
                                                 },
                                                 function(){
                                                 return false;
                                                 });
                                            }
                                            
                                            else if(userid_c.length < 3)
                                            {
                                            swal({
                                                 title: " ",
                                                 text: "User ID length must be minimum 3 characters"
                                                 },
                                                 function(){
                                                 return false;
                                                 });
                                            }
                                            else if(/\s/g.test(userid_c))
                                            {
                                            swal({
                                                 title: " ",
                                                 text: "User ID should not contain space."
                                                 },
                                                 function(){
                                                 return false;
                                                 });
                                            }
                                            else
                                            {
                                            
                                            var surl_forgot = base_url+'&userId='+res+'&functionId=1015&dpId='+dpid_c+'&clientId='+clientid_c+'';
                                            $("#backg").css("display", "block");
                                            setTimeout(function(){
                                                       var data = global_ajax(surl_forgot);
                                                       console.log(data);
                                                       var result = $.parseJSON(data);console.log(result.status);
                                                       var temp_dpid = result.dpId;
                                                       var temp_clientId = result.clientId;
                                                       var temp_userId = result.userId;
                                                       localStorage.setItem('temp_dpid', JSON.stringify(temp_dpid));
                                                       localStorage.setItem('temp_clientId', JSON.stringify(temp_clientId));
                                                       localStorage.setItem('temp_userId', JSON.stringify(temp_userId));
                                                       if(result.status == "S"){
                                                       // navigator.notification.alert(result.message, null," ");
                                                       swal({
                                                            title: " ",
                                                            text: result.message
                                                            },
                                                            function(){
                                                            var ReSetUserID = JSON.parse(localStorage.getItem('temp_userId'));
                                                            localStorage.setItem('resetUserID',JSON.stringify(ReSetUserID));
                                                            window.open("otp_pass.html",'_self',false);
                                                            });
                                                       
                                                       
                                                       }
                                                       else{
                                                       $("#backg").css("display", "none");
                                                       swal({
                                                            title: " ",
                                                            text: result.errorDescription
                                                            },
                                                            function(){
                                                            return false;
                                                            });
                                                       }
                                                       },100);
                                            
                                            }
                                            
                                            
                                            });
                  //OTP Validation reset password
                  $("#otp_reset_validation").click(function(){
                                                   
                                                   var otp_ios = $("#otp_ios").val();
                                                   var user_id = JSON.parse(localStorage.getItem('temp_userId'));
                                                   var dp_id = JSON.parse(localStorage.getItem('temp_dpid'));
                                                   var client_id = JSON.parse(localStorage.getItem('temp_clientId'));
                                                   var base_url = JSON.parse(localStorage.getItem('base_url'));
                                                   var surl_otp_reset_validation = base_url+'&userId='+user_id+'&functionId=1016&dpId='+dp_id+'&clientId='+client_id+'&otp='+otp_ios+'';
                                                   if(otp_ios == "")
                                                   {
                                                   swal({
                                                        title: " ",
                                                        text: "Please enter OTP"
                                                        },
                                                        function(){
                                                        return false;
                                                        });
                                                   }
                                                   else if(/\s/g.test(otp_ios))
                                                   {
                                                   swal({
                                                        title: " ",
                                                        text: "OTP should not contain spaces."
                                                        },
                                                        function(){
                                                        document.getElementById("otp_ios").value = "";
                                                        return false;
                                                        });
                                                   }
                                                   else if(isNaN(otp_ios)){
                                                   swal({
                                                        title: " ",
                                                        text: "OTP field should contain only numbers."
                                                        },
                                                        function(){
                                                        document.getElementById("otp_ios").value = "";
                                                        return false;
                                                        });
                                                   
                                                   }
                                                   else
                                                   {
                                                   $("#backg").css("display", "block");
                                                   setTimeout(function(){
                                                              var data = global_ajax(surl_otp_reset_validation);
                                                              console.log(data);
                                                              var result = $.parseJSON(data);console.log(result.status);
                                                              if(result.status == 'S'){
                                                              swal({
                                                                   title: " ",
                                                                   text: result.message
                                                                   },
                                                                   function(){
                                                                   window.open("reset_password.html",'_self',false);
                                                                   });
                                                              }
                                                              else{
                                                              $("#backg").css("display", "none");
                                                              swal({
                                                                   title: " ",
                                                                   text: result.errorDescription
                                                                   },
                                                                   function(){
                                                                   document.getElementById("otp_ios").value = "";
                                                                   return false;
                                                                   });
                                                              }
                                                              },100);
                                                   
                                                   
                                                   }
                                                   
                                                   });
                  
                  //OTP regenaration reset password
                  $("#otp_generation").click(function(){
                                             //$("#backg").css("display", "block");
                                             $("#backg").css("display", "block");
                                             var base_url = JSON.parse(localStorage.getItem('base_url'));
                                             setTimeout(function(){
                                                        var user_id = JSON.parse(localStorage.getItem('temp_userId'));
                                                        var dp_id = JSON.parse(localStorage.getItem('temp_dpid'));
                                                        var client_id = JSON.parse(localStorage.getItem('temp_clientId'));
                                                        
                                                        var surl_otp_generation = base_url+'&userId='+user_id+'&functionId=1017&dpId='+dp_id+'&clientId='+client_id+'';
                                                        var data = global_ajax(surl_otp_generation);
                                                        console.log(data);
                                                        var result = $.parseJSON(data);console.log(result.status);
                                                        if(result.status == 'S'){
                                                        $("#backg").css("display", "none");
                                                        swal({
                                                             title: " ",
                                                             text: result.message
                                                             },
                                                             function(){
                                                             document.getElementById("otp_ios").value = "";
                                                             return false;
                                                             });
                                                        }
                                                        else{
                                                        $("#backg").css("display", "none");
                                                        swal({
                                                             title: " ",
                                                             text: result.errorDescription
                                                             },
                                                             function(){
                                                             document.getElementById("otp_ios").value = "";
                                                             return false;
                                                             });
                                                        
                                                        }
                                                        },100);
                                             
                                             
                                             
                                             });
                  /********************************************END Reset Password**********************/
                  //Reset Password
                  $("#reset_submit").click(function(){
                                           var user_id = $("#userid").val();
                                           var dp_id = $("#dp_id").val();
                                           var client_id = $("#client_id").val();
                                           var password = $("#password").val();
                                           var confirm_pass = $("#c_password").val();
                                           var base_url = JSON.parse(localStorage.getItem('base_url'));
                                           if(password == "")
                                           {
                                           swal({
                                                title: " ",
                                                text: "Please enter Password."
                                                },
                                                function(){
                                                return false;
                                                });
                                           }
                                           else if(password.length < 8)
                                           {
                                           swal({
                                                title: " ",
                                                text: "Password length must be minimum 8 characters."
                                                },
                                                function(){
                                                document.getElementById("password").value = "";
                                                return false;
                                                });
                                           }
                                           else if( !((password.charAt(0)).match(/^[a-zA-Z0-9]/) ))
                                           {
                                           swal({
                                                title: " ",
                                                text: "Password should not start with a special character."
                                                },
                                                function(){
                                                return false;
                                                });
                                           }
                                           else if(password.match(/^[a-zA-Z]*$/))
                                           {
                                           swal({
                                                title: " ",
                                                text: "Password must contain atleast one alphabet and two numerics"
                                                },
                                                function(){
                                                document.getElementById("password").value = "";
                                                return false;
                                                });
                                           }
                                           else if(/\s/g.test(password))
                                           {
                                           swal({
                                                title: " ",
                                                text: "Password should not contain spaces"
                                                },
                                                function(){
                                                document.getElementById("password").value = "";
                                                return false;
                                                });
                                           }
                                           else if(confirm_pass == "")
                                           {
                                           swal({
                                                title: " ",
                                                text: "Please enter Confirm Password"
                                                },
                                                function(){
                                                return false;
                                                });
                                           }
                                           else if(confirm_pass != password)
                                           {
                                           swal({
                                                title: " ",
                                                text: "Password and confirm Password do not match, Please re-enter the password"
                                                },
                                                function(){
                                                document.getElementById("password").value = "";
                                                document.getElementById("c_password").value = "";
                                                return false;
                                                });
                                           }
                                           else
                                           {
                                           //$("#backg").css("display", "block");
                                           var surl_reset_pass = base_url+'&userId='+user_id+'&functionId=1018&dpId='+dp_id+'&clientId='+client_id+'&passWord='+encodeURIComponent($("#password").val())+'';
                                           $("#backg").css("display", "block");
                                           setTimeout(function(){
                                                      var data = global_ajax(surl_reset_pass);
                                                      console.log(data);
                                                      var result = $.parseJSON(data);console.log(result.status);
                                                      
                                                      if(result.status == "S"){
                                                      swal({
                                                           title: " ",
                                                           text: result.message
                                                           },
                                                           function(){
                                                           window.open("index.html",'_self',false);
                                                           });
                                                      }
                                                      else{
                                                      $("#backg").css("display", "none");
                                                      swal({
                                                           title: " ",
                                                           text: result.errorDescription
                                                           },
                                                           function(){
                                                           document.getElementById("password").value = "";
                                                           document.getElementById("c_password").value = "";
                                                           return false;
                                                           });
                                                      
                                                      }
                                                      },100);
                                           
                                           }
                                           
                                           
                                           });
                  
                  $("#otp_cancel").click(function(){
                                         window.open("index.html",'_self',false);
                                         });
                  
                  /********************************************Change Password**********************/
                  $("#changed").click(function(){
                                      
                                      var user_id = JSON.parse(localStorage.getItem('temp_userId1'));
                                      var dp_id = JSON.parse(localStorage.getItem('temp_dpid1'));
                                      var client_id = JSON.parse(localStorage.getItem('temp_clientId1'));
                                      var old_password = $("#old_password").val();
                                      var new_password = $("#new_password").val();
                                      var confirm_pass = $("#confirm_pass").val();
                                      var base_url = JSON.parse(localStorage.getItem('base_url'));
                                      if(old_password == "")
                                      {
                                      swal({
                                           title: " ",
                                           text: "Please enter Old Password."
                                           },
                                           function(){
                                           document.getElementById("confirm_pass").value = "";
                                           document.getElementById("new_password").value = "";
                                           return false;
                                           });
                                      }
                                      /* else if(old_password.match(/^[a-zA-Z]*$/))
                                       {
                                       swal({
                                       title: " ",
                                       text: "Password must contain atleast one alphabet and two numerics."
                                       },
                                       function(){
                                       document.getElementById("old_password").value = "";
                                       return false;
                                       });
                                       }*/
                                      else if(old_password.length < 8)
                                      {
                                      swal({
                                           title: " ",
                                           text: "Password Length must be minimum 8 characters."
                                           },
                                           function(){
                                           document.getElementById("old_password").value = "";
                                           return false;
                                           });
                                      }
                                      else if(new_password == ""){
                                      swal({
                                           title: " ",
                                           text: "Please enter New Password."
                                           },
                                           function(){
                                           return false;
                                           });
                                      }
                                      else if(new_password.length < 8)
                                      {
                                      swal({
                                           title: " ",
                                           text: "Password Length must be minimum 8 characters."
                                           },
                                           function(){
                                           document.getElementById("new_password").value = "";
                                           document.getElementById("confirm_pass").value = "";
                                           return false;
                                           });
                                      }
                                      else if( !((new_password.charAt(0)).match(/^[a-zA-Z0-9]/) ))
                                      {
                                      swal({
                                           title: " ",
                                           text: "Password should not start with a special character."
                                           },
                                           function(){
                                           document.getElementById("new_password").value = "";
                                           document.getElementById("confirm_pass").value = "";
                                           return false;
                                           });
                                      }
                                      else if(new_password.match(/^[a-zA-Z]*$/))
                                      {
                                      swal({
                                           title: " ",
                                           text: "Password must contain atleast one alphabet and two numerics."
                                           },
                                           function(){
                                           document.getElementById("new_password").value = "";
                                           document.getElementById("confirm_pass").value = "";
                                           return false;
                                           });
                                      }
                                      else if(new_password.match(/^[0-9]*$/))
                                      {
                                      swal({
                                           title: " ",
                                           text: "Password should not contain only numbers."
                                           },
                                           function(){
                                           document.getElementById("new_password").value = "";
                                           document.getElementById("confirm_pass").value = "";
                                           return false;
                                           });
                                      }
                                      else if(/\s/g.test(new_password))
                                      {
                                      swal({
                                           title: " ",
                                           text: "Password should not contain spaces."
                                           },
                                           function(){
                                           document.getElementById("new_password").value = "";
                                           document.getElementById("confirm_pass").value = "";
                                           return false;
                                           });
                                      }
                                      else if(confirm_pass == ""){
                                      swal({
                                           title: " ",
                                           text: "Please enter Confirm New Password."
                                           },
                                           function(){
                                           return false;
                                           });
                                      }
                                      else if(confirm_pass != new_password)
                                      {
                                      swal({
                                           title: " ",
                                           text: "Password and Confirm Password do not match, Please re-enter the Password."
                                           },
                                           function(){
                                           document.getElementById("new_password").value = "";
                                           document.getElementById("confirm_pass").value = "";
                                           return false;
                                           });
                                      }
                                      
                                      else{
                                      //$("#backg").css("display", "block");
                                      var surl_change_pass = base_url+'&userId='+user_id+'&functionId=1019&dpId='+dp_id+'&clientId='+client_id+'&oldPassword='+encodeURIComponent($("#old_password").val())+'&newPassword='+encodeURIComponent($("#new_password").val())+'';
                                      $("#backg").css("display", "block");
                                      setTimeout(function(){
                                                 var data = global_ajax(surl_change_pass);
                                                 console.log(data);
                                                 var result = $.parseJSON(data);
                                                 if(result.status == "S")
                                                 {
                                                 swal({
                                                      title: " ",
                                                      text: result.message
                                                      },
                                                      function(){
                                                      window.open("index.html",'_self',false);
                                                      });
                                                 }
                                                 else if(result.status == "F" && result.errorCode == "1007"){
                                                 $("#backg").css("display", "none");
                                                 swal({
                                                      title: " ",
                                                      text: result.errorDescription
                                                      },
                                                      function(){
                                                      document.getElementById("old_password").value = "";
                                                      document.getElementById("new_password").value = "";
                                                      document.getElementById("confirm_pass").value = "";
                                                      return false;
                                                      });
                                                 }
                                                 
                                                 else
                                                 {
                                                 $("#backg").css("display", "none");
                                                 swal({
                                                      title: " ",
                                                      text: result.errorDescription
                                                      },
                                                      function(){
                                                      document.getElementById("old_password").value = "";
                                                      document.getElementById("new_password").value = "";
                                                      document.getElementById("confirm_pass").value = "";
                                                      return false;
                                                      });
                                                 }
                                                 },100);
                                      
                                      }
                                      
                                      });
                  /********************************************END Change Password**********************/
                  
                  /********************************************Password Expired************************/
                  $("#passwordExpired").click(function(){
                                              ios_uuid = device.uuid;var VersionNumber;
                                              localStorage.setItem('iosUuid', JSON.stringify(ios_uuid));
                                              cordova.getAppVersion(function (version) {
                                                                    VersionNumber = version;
                                                                    localStorage.setItem('VersionNumber', JSON.stringify(VersionNumber));
                                                                    
                                                                    });
                                              var base_url = server_url+"mobDeviceOS=IOS&mobAppVersion="+JSON.parse(localStorage.getItem('VersionNumber'))+"&imeiNumber="+ios_uuid+"&mobOSVersion=6.0&mobDeviceUuId="+ios_uuid+"";
                                              
                                              localStorage.setItem('base_url', JSON.stringify(base_url));
                                              var user_id = JSON.parse(localStorage.getItem('exUserId'));
                                              var dp_id = JSON.parse(localStorage.getItem('exdpId'));
                                              var client_id = JSON.parse(localStorage.getItem('exclientId'));
                                              var old_password = $("#old_password").val();
                                              var new_password = $("#new_password").val();
                                              var confirm_pass = $("#confirm_pass").val();
                                              var base_url = JSON.parse(localStorage.getItem('base_url'));
                                              if(old_password == "")
                                              {
                                              swal({
                                                   title: " ",
                                                   text: "Please enter Old Password."
                                                   },
                                                   function(){
                                                   document.getElementById("confirm_pass").value = "";
                                                   document.getElementById("new_password").value = "";
                                                   return false;
                                                   });
                                              }
                                              /* else if(old_password.match(/^[a-zA-Z]*$/))
                                               {
                                               swal({
                                               title: " ",
                                               text: "Password must contain atleast one alphabet and two numerics."
                                               },
                                               function(){
                                               document.getElementById("old_password").value = "";
                                               return false;
                                               });
                                               }*/
                                              else if(old_password.length < 8)
                                              {
                                              swal({
                                                   title: " ",
                                                   text: "Password Length must be minimum 8 characters."
                                                   },
                                                   function(){
                                                   document.getElementById("old_password").value = "";
                                                   return false;
                                                   });
                                              }
                                              else if(new_password == ""){
                                              swal({
                                                   title: " ",
                                                   text: "Please enter New Password."
                                                   },
                                                   function(){
                                                   document.getElementById("new_password").value = "";
                                                   document.getElementById("confirm_pass").value = "";
                                                   return false;
                                                   });
                                              }
                                              else if(new_password.length < 8)
                                              {
                                              swal({
                                                   title: " ",
                                                   text: "Password Length must be minimum 8 characters."
                                                   },
                                                   function(){
                                                   document.getElementById("new_password").value = "";
                                                   document.getElementById("confirm_pass").value = "";
                                                   return false;
                                                   });
                                              }
                                              else if( !((new_password.charAt(0)).match(/^[a-zA-Z0-9]/) ))
                                              {
                                              swal({
                                                   title: " ",
                                                   text: "Password should not start with a special character."
                                                   },
                                                   function(){
                                                   document.getElementById("new_password").value = "";
                                                   document.getElementById("confirm_pass").value = "";
                                                   return false;
                                                   });
                                              }
                                              else if(new_password.match(/^[a-zA-Z]*$/))
                                              {
                                              swal({
                                                   title: " ",
                                                   text: "Password must contain atleast one alphabet and two numerics."
                                                   },
                                                   function(){
                                                   document.getElementById("new_password").value = "";
                                                   document.getElementById("confirm_pass").value = "";
                                                   return false;
                                                   });
                                              }
                                              else if(new_password.match(/^[0-9]*$/))
                                              {
                                              swal({
                                                   title: " ",
                                                   text: "Password should not contain only numbers."
                                                   },
                                                   function(){
                                                   document.getElementById("new_password").value = "";
                                                   document.getElementById("confirm_pass").value = "";
                                                   return false;
                                                   });
                                              }
                                              else if(/\s/g.test(new_password))
                                              {
                                              swal({
                                                   title: " ",
                                                   text: "Password should not contain spaces."
                                                   },
                                                   function(){
                                                   document.getElementById("new_password").value = "";
                                                   document.getElementById("confirm_pass").value = "";
                                                   return false;
                                                   });
                                              }
                                              else if(confirm_pass == ""){
                                              swal({
                                                   title: " ",
                                                   text: "Please enter Confirm New Password."
                                                   },
                                                   function(){
                                                   return false;
                                                   });
                                              }
                                              else if(confirm_pass != new_password)
                                              {
                                              swal({
                                                   title: " ",
                                                   text: "Password and Confirm Password do not match, Please re-enter the Password."
                                                   },
                                                   function(){
                                                   document.getElementById("new_password").value = "";
                                                   document.getElementById("confirm_pass").value = "";
                                                   return false;
                                                   });
                                              }
                                              
                                              else{
                                              //$("#backg").css("display", "block");
                                              var surl_change_pass = base_url+'&userId='+user_id+'&functionId=1019&dpId='+dp_id+'&clientId='+client_id+'&oldPassword='+encodeURIComponent($("#old_password").val())+'&newPassword='+encodeURIComponent($("#new_password").val())+'';
                                              
                                              $("#backg").css("display", "block");
                                              setTimeout(function(){
                                                         var data = global_ajax(surl_change_pass);
                                                         console.log(data);
                                                         var result = $.parseJSON(data);
                                                         if(result.status == "S")
                                                         {
                                                         swal({
                                                              title: " ",
                                                              text: result.message
                                                              },
                                                              function(){
                                                              window.open("index.html",'_self',false);
                                                              });
                                                         }
                                                         else if(result.status == "F" && result.errorCode == "1007"){
                                                         $("#backg").css("display", "none");
                                                         swal({
                                                              title: " ",
                                                              text: result.errorDescription
                                                              },
                                                              function(){
                                                              document.getElementById("old_password").value = "";
                                                              document.getElementById("new_password").value = "";
                                                              document.getElementById("confirm_pass").value = "";
                                                              return false;
                                                              });
                                                         }
                                                         
                                                         else
                                                         {
                                                         $("#backg").css("display", "none");
                                                         swal({
                                                              title: " ",
                                                              text: result.errorDescription
                                                              },
                                                              function(){
                                                              document.getElementById("old_password").value = "";
                                                              document.getElementById("new_password").value = "";
                                                              document.getElementById("confirm_pass").value = "";
                                                              return false;
                                                              });
                                                         }
                                                         },100);
                                              
                                              }
                                              
                                              });
                  /*******************************************END**************************************/
                  
                  /********************************************SOH Ticker**********************/
                  $(".scrollingtext").click(function(){
                                            $("#POPUpTicker").show();$("#PopTicker").show();
                                            $("#appendTicker").html('Value is based on the price (i.e.equity shares) as on :'+JSON.parse(localStorage.getItem('secDate'))+' price (i.e.E-series Commodities) as on : '+JSON.parse(localStorage.getItem('commodityDate'))+ ' and NAV (i.e.Mutual Fund) as on:'+JSON.parse(localStorage.getItem('navDate')));
                                            
                                            
                                            });
                  $("#closePopTicker").click(function(){
                                             $("#POPUpTicker").hide();$("#PopTicker").hide();
                                             
                                             });
                  
                  /********************************************SOH Ticker END**********************/
                  /********************************************EDIS Accept/Reject**********************/
                  $("#accept").click(function(){
                                     $("#backg").css("display", "block");
                                     var base_url = JSON.parse(localStorage.getItem('base_url'));
                                     setTimeout(function(){
                                                var array_edis_instNo = JSON.parse(localStorage.getItem('ids_edis'));
                                                var user_id = JSON.parse(localStorage.getItem('temp_userId1'));
                                                var dp_id = JSON.parse(localStorage.getItem('temp_dpid1'));
                                                var client_id = JSON.parse(localStorage.getItem('temp_clientId1'));
                                                var edis_action = JSON.parse(localStorage.getItem('submit_action'));
                                                var surl_edis_confirm = base_url+'&userId='+user_id+'&functionId=1009&dpId='+dp_id+'&clientId='+client_id+'&instrNumberList='+array_edis_instNo+'&confirmationIndicator='+edis_action+'';
                                                var data = global_ajax(surl_edis_confirm);
                                                console.log(data);
                                                var edis_ack = data;
                                                localStorage.setItem('edis_ack', JSON.stringify(edis_ack));
                                                var result = $.parseJSON(data);
                                                var edis_tm = result.instrConfTimestamp;
                                                if(result.status == "S"){
                                                swal({
                                                     title: " ",
                                                     text: 'Your instruction has been successfully received by SPEED-e on '+edis_tm
                                                     },
                                                     function(){
                                                     window.open("edis_ack.html","_self",false);
                                                     });
                                                }
                                                else
                                                {
                                                $("#backg").css("display", "none");
                                                swal({
                                                     title: " ",
                                                     text: result.errorDescription
                                                     },
                                                     function(){
                                                     return false;
                                                     });
                                                }
                                                },100);
                                     
                                     
                                     });
                  $(".submit_edis").click(function(){
                                          
                                          var checked = $("#EDIS_list input:checked").length > 0;
                                          
                                          if (!checked){
                                          swal({
                                               title: " ",
                                               text: "Please select one or more Instructions"
                                               },
                                               function(){
                                               return false;
                                               });
                                          }
                                          
                                          else
                                          {
                                          $("#backg").css("display", "block");
                                          var submit_action = this.id;
                                          var text =  $('input:checked').each(function () {
                                                                              ids = this.id;
                                                                              ids_edis.push(ids);
                                                                              console.log(ids_edis);
                                                                              });
                                          localStorage.setItem('ids_edis', JSON.stringify(ids_edis));
                                          localStorage.setItem('submit_action', JSON.stringify(submit_action));
                                          window.open("edis_confirm_list.html",'_self',false);
                                          }
                                          
                                          
                                          });
                  $("#cancel_edis").click(function(){
                                          window.open("edis.html",'_self',false);
                                          });
                  $("#back_history_edis").click(function(){
                                                $(".overlay_user").hide();
                                                window.open("edis.html",'_self',false);
                                                });
                  
                  $(".edis_show_hide3 .checkAll").click(function () {
                                                        if ($(".edis_show_hide3 .checkAll").is(':checked')) {
                                                        $("#EDIS_list input[type=checkbox]").each(function () {
                                                                                                  $(this).prop("checked", true);
                                                                                                  });
                                                        
                                                        }
                                                        
                                                        else {
                                                        $("#EDIS_list input[type=checkbox]").each(function () {
                                                                                                  $(this).prop("checked", false);
                                                                                                  });
                                                        }
                                                        });
                  //$(".ui-btn").css("background-color", "#8a221d");
                  
                  /********************************************END EDIS Accept/reject**********************/
                  $(".soh_details").click(function(){
                                          $("#backg").css("display", "block");
                                          FreeUser = "freeUser";
                                          localStorage.setItem('FreeUser', JSON.stringify(FreeUser));
                                          $(".overlay_user").hide();
                                          window.open("equity.html",'_self',false);
                                          });
                  /********************************************POP UP**********************/
                  $("#beneficiary").click(function(){
                                          $("#PopUpbenefiaryOverlay").show();$("#PopUpbenefiary").show();
                                          
                                          });
                  $("#closePopbenefiary").click(function(){
                                                $("#PopUpbenefiaryOverlay").hide();$("#PopUpbenefiary").hide();
                                                });
                  
                  $("#disclaimer").click(function(){
                                         $("#POPOverlayDisclaimer").show();$("#PopDisclaimer").show();
                                         //$("#overlay_d").show();$("#model_d").show();
                                         
                                         });
                  $("#closePopdisclaimer").click(function(){
                                                 $("#POPOverlayDisclaimer").hide();$("#PopDisclaimer").hide();
                                                 });
                  /********************************************POP UP END**********************/
                  $(".soh_refresh").click(function(){
                                          
                                          $("#backg").css("display", "block");
                                          FreeUser = "freeUser";
                                          localStorage.setItem('FreeUser', JSON.stringify(FreeUser));
                                          $(".overlay_user").hide();
                                          var base_url = JSON.parse(localStorage.getItem('base_url'));
                                          setTimeout(function(){
                                                     //var FreeUser = "freeUser";
                                                     //localStorage.setItem('FreeUser', JSON.stringify(FreeUser));
                                                     var user_id = JSON.parse(localStorage.getItem('temp_userId1'));
                                                     var dp_id = JSON.parse(localStorage.getItem('temp_dpid1'));
                                                     var client_id = JSON.parse(localStorage.getItem('temp_clientId1'));
                                                     var password = encodeURIComponent(JSON.parse(localStorage.getItem('temp_password')));
                                                     var surl_login_refresh = base_url +'&functionId=1000&userId='+user_id+'&passWord='+password+'';
                                                     var surl_soh_refresh = base_url+'&userId='+user_id+'&functionId=1001&dpId='+dp_id+'&clientId='+client_id+'';
                                                     var data = global_ajax(surl_login_refresh);
                                                     console.log(data);
                                                     var result = $.parseJSON(data);
                                                     if(result.status == "S"){
                                                     var data = FreeUserSoh(surl_soh_refresh);
                                                     console.log(data);
                                                     var soh_data = data;
                                                     localStorage.setItem('soh_data', JSON.stringify(data));
                                                     window.open("equity.html","_self",false);
                                                     }
                                                     else{
                                                     $("#backg").css("display", "none");
                                                     swal({
                                                          title: " ",
                                                          text: result.errorDescription
                                                          },
                                                          function(){
                                                          return false;
                                                          });
                                                     }
                                                     },100);
                                          
                                          });
                  });

function soh_details(){
    FreeUser = "freeUser";
    localStorage.setItem('FreeUser', JSON.stringify(FreeUser));
    $(".overlay_user").hide();
    window.open("equity.html",'_self',false);
}
function edis(){
    var ccr_f = JSON.parse(localStorage.getItem('ccrflag'));
    var mob_f = JSON.parse(localStorage.getItem('mob_flag'));
    var userType = JSON.parse(localStorage.getItem('userType'));
    if(ccr_f == "Y" && mob_f == "MOB" && userType == "INV")
    {
        window.open("edis.html","_self",false);
        
    }
    
    else
    {
        swal({
             title: " ",
             text: "You have not activated e-DIS service,Please contact NSDL HelpDesk for further assistance."
             },
             function(){
             $(".edis").off("click");
             $("#backg").css("display", "none");
             return false;
             });
        
    }
    
}
function menu_pass(){
    window.open("change_password.html",'_self',false);
    
}
function logout(){
    navigator.notification.confirm('Do you really want to Exit',onConfirm," ",['No','Yes']);
    
}
function contact(){
    $("#backg").css("display", "block");
    window.open("contactUs.html",'_self',false);
}
function reset_call()
{
    $("#dp_id").val(JSON.parse(localStorage.getItem('temp_dpid')));
    $("#client_id").val(JSON.parse(localStorage.getItem('temp_clientId')));
    $("#userid").val(JSON.parse(localStorage.getItem('temp_userId')));
    var ReSetUserID = JSON.parse(localStorage.getItem('temp_userId'));
    localStorage.setItem('resetUserID',JSON.stringify(ReSetUserID));
    
}
function changep(){
    //$("#account_status_u").html(": "+JSON.parse(localStorage.getItem('acc_status')));
    $("#soh_count").html(JSON.parse(localStorage.getItem('temp_holding'))+" ISIN's");
    $("#edis_count").html(JSON.parse(localStorage.getItem('edis_length')) + " Pending");
    
}

var acc_status;
var count = 0;
function SOH()
{
    if( JSON.parse(localStorage.getItem('soh_data')) == "RequestTimeOut" )
    {
        $("#loading").html("");
        $("#loading").html("The request timed out");
        $(".refresh_soh").show();
        // var secDate = result.secDate;var commodityDate = result.commodityDate;var navDate = result.navDate;
        var temp_businessDate = 'Statement of Holding as on :'+' '+JSON.parse(localStorage.getItem('temp_current_dt'));
        $("#businessDate").html(temp_businessDate);
        $("#totalValueOfHoldings").html('&#8377;<b>0.00</b>');
        //$("#account_status_u").html(': Active');
        accountStatus = "Active";
        localStorage.setItem('acc_status', JSON.stringify(accountStatus));
        temp_holding = "0";
        localStorage.setItem('temp_holding', JSON.stringify(temp_holding));
        $("#account_status_u").html(" ");
        $("#soh_count").html(JSON.parse(localStorage.getItem('temp_holding'))+" ISIN's");
        $("#edis_count").html(JSON.parse(localStorage.getItem('edis_length'))+" Pending");
        return false;
    }
    else{
        if(JSON.parse(localStorage.getItem('FreeUser')) == "freeUser"){
            $(".SlideMenu").hide();
            $(".overlay_user").hide();
            $('.slide-in').toggleClass('on');
            $('.main_wrapper').toggleClass('on');
            outIn = 'in';
            
        }
        else{
            $('.slide-in').toggleClass('on');
            $('.main_wrapper').toggleClass('on');
            $(".overlay_user").hide();
            setTimeout(function(){
                       $('.slide-in').toggleClass('on');
                       $('.main_wrapper').toggleClass('on');
                       $(".overlay_user").hide();
                       outIn = 'in';
                       }, 3000);
            
        }
        var temp_count = count++;
        localStorage.setItem('temp_count', JSON.stringify(temp_count));
        var data = JSON.parse(localStorage.getItem('soh_data'));
        var result = $.parseJSON(data);console.log(result);
        
        if(result.status == "F")
        {
            
            if(result.invAccStatus){
                accountStatus = result.invAccStatus;
                localStorage.setItem('acc_status', JSON.stringify(accountStatus));
            }
            else{
                accountStatus = " ";
                localStorage.setItem('acc_status', JSON.stringify(accountStatus));
                
            }
            $("#loading").html("");
            $("#loading").html(result.errorDescription);
            $(".refresh_soh").show();
            // var secDate = result.secDate;var commodityDate = result.commodityDate;var navDate = result.navDate;
            if(result.secDate || result.commodityDate || result.navDate){
                var secDate = result.secDate;var commodityDate = result.commodityDate;var navDate = result.navDate;
                localStorage.setItem('secDate', JSON.stringify(secDate));
                localStorage.setItem('commodityDate', JSON.stringify(commodityDate));
                localStorage.setItem('navDate', JSON.stringify(navDate));
                $(".scrollingtext").html('<marquee behavior=scroll direction="left" scrollamount="3">'+"Value is based on the price (i.e.equity shares) as on : "+result.secDate+" price (i.e.E-series Commodities) as on :"+result.commodityDate+""+" and NAV (i.e.Mutual Fund) as on:"+result.navDate+'</marquee>');
                
            }
            else{
                console.log("checked response");
            }
            
            var temp_businessDate = 'Statement of Holding as on :'+' '+JSON.parse(localStorage.getItem('temp_current_dt'));
            $("#businessDate").html(temp_businessDate);
            $("#totalValueOfHoldings").html('&#8377;<b>0.00</b>');
            //$("#account_status_u").html(': Active');
            if(result.invAccStatus){
                accountStatus = result.invAccStatus;
                localStorage.setItem('acc_status', JSON.stringify(accountStatus));
            }
            else{
                accountStatus = " ";
                localStorage.setItem('acc_status', JSON.stringify(accountStatus));
                
            }
            temp_holding = "0";
            localStorage.setItem('temp_holding', JSON.stringify(temp_holding));
            $("#account_status_u").html(JSON.parse(localStorage.getItem('acc_status')));
            $("#soh_count").html(JSON.parse(localStorage.getItem('temp_holding'))+" ISIN's");
            $("#edis_count").html(JSON.parse(localStorage.getItem('edis_length'))+" Pending");
        }
        else
        {
            if(result.invAccStatus){
                accountStatus = result.invAccStatus;
                localStorage.setItem('acc_status', JSON.stringify(accountStatus));
            }
            else{
                accountStatus = " ";
                localStorage.setItem('acc_status', JSON.stringify(accountStatus));
                
            }
            $("#account_status_u").html(JSON.parse(localStorage.getItem('acc_status')));
            $("#loading").hide();$(".refresh_soh").hide();
            var secDate = result.secDate;var commodityDate = result.commodityDate;var navDate = result.navDate;
            localStorage.setItem('secDate', JSON.stringify(secDate));
            localStorage.setItem('commodityDate', JSON.stringify(commodityDate));
            localStorage.setItem('navDate', JSON.stringify(navDate));
            var temp_holding = result.normalHoldingsList;
            localStorage.setItem('temp_holding', JSON.stringify(temp_holding.length));
            $("#soh_count").html(JSON.parse(localStorage.getItem('temp_holding'))+" ISIN's");
            $("#edis_count").html(JSON.parse(localStorage.getItem('edis_length'))+" Pending");
            
            var temp_businessDate = 'Statement of Holding as on :'+' '+result.businessDate;
            $("#totalValueOfHoldings").html('<b>'+number_format(result.totalValueOfHoldings)+'</b>');
            $("#businessDate").html(temp_businessDate);
            $(".scrollingtext").html('<marquee behavior=scroll direction="left" scrollamount="3">'+"Value is based on the price (i.e.equity shares) as on : "+result.secDate+" price (i.e.E-series Commodities) as on :"+result.commodityDate+""+" and NAV (i.e.Mutual Fund) as on:"+result.navDate+'</marquee>');
            //$("#ISIN_table").append('<table class="eq_table" border="0" width="100%" id="ISIN_list"></table>')
            for(var i=0;i<temp_holding.length;i++)
            {
                $("#ISIN_table").append('<table class="eq_table eq_table_list content_wrap" border="0" width="100%" id='+temp_holding[i].isinNumber+' onclick="soh_holding(this.id);"><tr><td width="50%" align="left" valign="left" style="padding-left:5px;">'+temp_holding[i].isinNumber+'<div style="color:#edc218;">'+temp_holding[i].isinName+'</div></td><td width="25%" align="left" valign="top">'+number_format_s(temp_holding[i].isinPrice)+'</div></td><td width="25%" align="left" valign="top" style="padding-right:5px;">'+number_format_s(temp_holding[i].isinValue)+'</td></tr><tr><td width="50%" align="left" valign="bottom" style="padding-left:5px;">'+temp_holding[i].isinLastTrDate+'</td><td width="25%" align="left" valign="bottom" style="color:#edc218;">'+number_format_s(temp_holding[i].isinBalance)+'</td><td width="25%">&nbsp;</td></tr><tr class="soh_label"><td width="100" align="right" valign="right" colspan="3"><img src="img/back_button.png" style="float:right;"/></td></tr></table>');
                
            }
        }
        
    }
    
}



function soh_holding(id)
{
    $("#backg").css("display", "block");
    var base_url = JSON.parse(localStorage.getItem('base_url'));
    setTimeout(function(){
               var user_id = JSON.parse(localStorage.getItem('temp_userId1'));
               var dp_id = JSON.parse(localStorage.getItem('temp_dpid1'));
               var client_id = JSON.parse(localStorage.getItem('temp_clientId1'));
               var surl_soh_holding = base_url+'&userId='+user_id+'&functionId=1002&dpId='+dp_id+'&clientId='+client_id+'&requestedISIN='+id+'';
               var data = global_ajax(surl_soh_holding);
               var soh_holding_data = data;
               localStorage.setItem('soh_holding_data', JSON.stringify(soh_holding_data));
               window.open("soh_holding_details.html",'_self',false);
               },100);
    
}
function soh_holding_details()
{
    //if (box1) box1.remove();
    var data1 = JSON.parse(localStorage.getItem('soh_holding_data'));
    var result = $.parseJSON(data1);
    console.log(data1);
    if(result.status == "S")
    {
        $("#isin").html(result.isinNumber);
        $("#isin_des").html(result.isinName);
        $("#beneficiary_free_bal").html(result.benificiaryFreeBalance);
        $("#block").html(result.block);
        $("#lockin").html(result.lockin);
        $("#demat_unlock").html(result.dmatUnlock);
        $("#remat_unlock").html(result.rematUnlock);
        $("#remat_lockin").html(result.rematLockin);
        $("#pledge").html(result.pledge);
        $("#pledge_lockin").html(result.pledgeLockin);
        $("#pledge_transit_unlock").html(result.pledgeTransitUnlock);
        $("#pledge_lockin_transit").html(result.pledgeLockinTransit);
        $("#blocked_idt").html(result.blockedIDT);
    }
    else
    {
        swal({
             title: " ",
             text: result.errorDescription
             },
             function(){
             return false;
             });
    }
    
}
var collect_data = [];
function edis_list()
{
    var data = JSON.parse(localStorage.getItem('edis_data'));
    var result = $.parseJSON(data);console.log(data);
    
    if(result.status == "F")
    {
        $(".page1").hide();$(".page2").show();
        $("#loading").html(result.errorDescription);
        console.log(result.errorDescription);
        
    }
    else{
        $(".page1").show();$(".page2").hide();
        var temp_edis = result.pendingInstructionList;
        
        for(var i=0;i<temp_edis.length;i++)
        {
            
            $("#EDIS_list").append('<table width="99%" border="0" align="center" cellpadding="0" cellspacing="0" class="edis_table content_wrap" style="border-collapse: collapse;margin-top:.5em;border:1px solid #fff001;">'
                                   +'<tr style="color:#fff;">'
                                   +'<td colspan="3" height="30"><input type="checkbox" id="'+temp_edis[i].instrNumber+'" name="checklist" class="single_select" onchange="ss();"/>&nbsp;&nbsp;&nbsp;'+temp_edis[i].isinNumber+'-<span style="color:#edc218;">'+temp_edis[i].companyName+'</span></td>'
                                   +'</tr>'
                                   +'<tr>'+'<td width="100" align="left" valign="left" height="30" style="padding-left:5px;color:#fff;">'+temp_edis[i].executionDate+'</td><td width="100" align="left" valign="middle" height="30" style="color:#edc218;">'+temp_edis[i].quantity+'</td><td width="100" align="left" valign="middle" height="30" style="color:#edc218;">'+temp_edis[i].marketType+'</td>'+'</tr><tr class="esid_b"><td class="rlabel" align="left" valign="left" colspan="3" height="30"><span style="color:#fff;">CM : </span><span style="color:#edc218;">'+temp_edis[i].clearingMemberId+' - '+temp_edis[i].clearingMemberName+'</span></td>'
                                   +'</tr><tr class="esid_b">'+'<td class="rlabel" align="left" valign="left" colspan="3" height="30"><span style="color:#fff;">Clearing House : </span><span style="color:#edc218;">'+temp_edis[i].ccId+'</span></td>'
                                   
                                   +'</tr><tr class="esid_b">'+'<td class="rlabel" colspan="3" height="30"><span style="color:#fff;">Sett. NO. : </span><span style="color:#edc218;">'+temp_edis[i].settlementNumber+'</span><span style="color:#fff;">&nbsp;&nbsp;&nbsp;Inst No. : </span><span style="color:#edc218;">'+temp_edis[i].instrNumber+'</span></td>'
                                   +'</tr><tr class="esid_b" style="border-bottom:1px solid #fff001;">'+'<td class="rlabel" align="left" valign="left" colspan="3" height="30"><span style="color:#fff;">Trans. NO. : </span><span style="color:#edc218;">'+temp_edis[i].transactionNo+'</span></td>'+'<tr>'+'</table>');
            
            
        }
        
    }
    $("#soh_count").html(JSON.parse(localStorage.getItem('temp_holding'))+" ISIN's");
    $("#edis_count").html(JSON.parse(localStorage.getItem('edis_length')) + " Pending");
    $("#account_status_u").html(JSON.parse(localStorage.getItem('acc_status')));
}
/*check for select all and uncheck single checkbox*/
function ss()
{
    var check = ($('.single_select').filter(":checked").length == $('.single_select').length);
    $('.checkAll').prop("checked", check);
}


function edis_ack(){
    var data = JSON.parse(localStorage.getItem('edis_ack'));
    console.log(data);
    var result = $.parseJSON(data);console.log(result.status);
    var temp_edis_ack = result.message;
    if(result.status == "S"){
        $("#loading").hide();
        for(var i =0;i< temp_edis_ack.length;i++){
            $("#EDIS_ACK_table").append('<table width="99%" id="EDIS_ACK_list" class="content_wrap" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#000" style="border-collapse: collapse;color:#fff;"><tr><td class="rlabel" width="44%" valign="top" height="20">Instruction Number</td><td align="center" valign="top" height="20">&nbsp;:&nbsp;</td><td align="left" valign="top" height="20">'+temp_edis_ack[i].instructionId+'</td></tr><tr><td class="rlabel" width="44%" valign="top" height="20">Execution date</td><td align="center" valign="top" height="20">&nbsp;:&nbsp;</td><td height="20" align="left" valign="top">'+temp_edis_ack[i].newExecDate+'</td></tr><tr class="soh_label"><td class="rlabel" width="44%" valign="top" height="20">Status</td><td align="center" valign="top" height="20">&nbsp;:&nbsp;</td><td align="left" valign="top" height="20">'+temp_edis_ack[i].statusMessage+'</td></tr></table>');
        }
        
    }
    else{
        $("#loading").html(result.errorDescription);
    }
    
}
function test22(){
    var data = JSON.parse(localStorage.getItem('edis_data'));
    var result = $.parseJSON(data);console.log(data);
    var check = JSON.parse(localStorage.getItem('ids_edis'));
    var temp_edis = result.pendingInstructionList;
    $("#EDIS_table").append('<table class="eq_table content_wrap" border="0" width="99%" id="edis_confirmation_list"></table>')
    for(var i=0;i<temp_edis.length;i++){
        for(var j=0;j < check.length;j++){
            
            if(temp_edis[i].instrNumber == check[j]){
                $("#edis_confirmation_list").append('<tr><td class="rlabel" height="40" style="width:39%;" valign="top">ISIN</td><td align="center" valign="top" height="40">&nbsp;:&nbsp;</td><td height="40" align="left" valign="top">'+temp_edis[i].companyName+'</td></tr><tr><td class="rlabel" height="40" style="width:39%;" valign="top">Quantity</td><td align="center" valign="top" height="40">&nbsp;:&nbsp;</td><td height="40" align="left" valign="top">'+temp_edis[i].quantity+'</td></tr><tr><td class="rlabel" height="40" style="width:39%;" valign="top">Execution Date</td><td align="center" valign="top" height="40">&nbsp;:&nbsp;</td><td height="40" align="left" valign="top">'+temp_edis[i].executionDate+'</td></tr><tr><td class="rlabel" height="40" style="width:39%;" valign="top">CM</td><td align="center" valign="top" height="40">&nbsp;:&nbsp;</td><td height="40" align="left" valign="top">'+temp_edis[i].clearingMemberId+' - '+temp_edis[i].clearingMemberName+'</td></tr><tr><td class="rlabel" height="40" style="width:39%;" valign="top">Clearing House</td><td align="center" valign="top" height="40">&nbsp;:&nbsp;</td><td height="40" align="left" valign="top"> '+temp_edis[i].ccId+'</td></tr><tr><td class="rlabel" height="40" style="width:39%;" valign="top">Market Type</td><td align="center" valign="top" height="40">&nbsp;:&nbsp;</td><td height="40" align="left" valign="top">'+temp_edis[i].marketType+'</td></tr><tr><td class="rlabel" height="40" style="width:39%;" valign="top">Sett. No.</td><td align="center" valign="top" height="40">&nbsp;:&nbsp;</td><td height="40" align="left" valign="top">'+temp_edis[i].settlementNumber+'</td></tr><tr><td class="rlabel" height="40" style="width:39%;" valign="top">Transaction No.</td><td align="center" valign="top" height="40">&nbsp;:&nbsp;</td><td height="40" align="left" valign="top">'+temp_edis[i].transactionNo+'</td></tr><tr class="soh_label"><td class="rlabel" height="40" style="width:39%;" valign="top">Inst. No.</td><td align="center" valign="top" height="40">&nbsp;:&nbsp;</td><td height="40" align="left" valign="top">'+temp_edis[i].instrNumber+'</td></tr><br />');
                
            }
            else{
                console.log("no response..");
            }
        }
        
    }
    
}

//portfolio refresh
function portfolio_refresh(){
    $("#backg").css("display", "block");
    var base_url = JSON.parse(localStorage.getItem('base_url'));
    var accountStatus;
    setTimeout(function(){
               var user_id = JSON.parse(localStorage.getItem('temp_userId1'));
               var dp_id = JSON.parse(localStorage.getItem('temp_dpid1'));
               var client_id = JSON.parse(localStorage.getItem('temp_clientId1'));
               var portfolio_url = base_url+'&userId='+user_id+'&functionId=2001&dpId='+dp_id+'&clientId='+client_id+'';
               var RTO = "NO";
               localStorage.setItem('RTO', JSON.stringify(RTO));
               $.ajax({
                      type: "GET",
                      url: portfolio_url,
                      dataType:"html",
                      cache:false,
                      crossDomain: true,
                      async: false,
                      
                      success: function (data) {
                      result = data;
                      console.log(data);
                      var result = $.parseJSON(data);
                      if(!result.invAccStatus){
                      accountStatus = "Active";
                      localStorage.setItem('acc_status', JSON.stringify(accountStatus));
                      }
                      else{
                      accountStatus = result.invAccStatus;
                      localStorage.setItem('acc_status', JSON.stringify(accountStatus));
                      }
                      
                      var portfolio_refresh = data;
                      localStorage.setItem('portfolio_data', JSON.stringify(portfolio_refresh));
                      if(result.status == "S")
                      {
                      var portfolio_2003 = base_url+'&userId='+user_id+'&functionId=2003&dpId='+dp_id+'&clientId='+client_id+'';
                      var data = global_ajax(portfolio_2003);
                      
                      console.log(data);
                      var paid_2003 = data;
                      localStorage.setItem('paid_2003', JSON.stringify(paid_2003));
                      var result = $.parseJSON(data);
                      window.open("portfolio.html",'_self',false);
                      }
                      else{
                      window.open("portfolio.html",'_self',false);
                      
                      }
                      },
                      error: function (xhr, status, error) {
                      $("#backg").css("display", "none");
                      var RTO = "RequestTimeOut";
                      localStorage.setItem('RTO', JSON.stringify(RTO));
                      swal({
                           title: " ",
                           text: "The request timed out."
                           },
                           function(){
                           window.open("portfolio.html",'_self',false);
                           });
                      
                      }
                      });
               
               
               },100);
    
}
