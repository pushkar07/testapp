

var getLine_id = "line_gy";var db;
//json array for security order..

var base_url = JSON.parse(localStorage.getItem('base_url'));
  var security_order = '{"portfolio":[{"secType":"1","secType_des":"Equity","sec_order":"1","name":"Equity","color":"#fdc12a"},{"secType":"2","secType_des":"Postal Saving Scheme","sec_order":"8","name":"Postal Saving Scheme","color":"#6600cd"},{"secType":"3","secType_des":"Preference Shares","sec_order":"2","name":"Preference Shares","color":"#caadff"},{"secType":"4","secType_des":"Bond","sec_order":"4","name":"Corporate Bonds","color":"#055ba5"},{"secType":"5","secType_des":"Deep Discount Bond","sec_order":"4","name":"Corporate Bonds","color":"#055ba5"},{"secType":"6","secType_des":"Floating Rate Bond","sec_order":"4","name":"Corporate Bonds","color":"#055ba5"},{"secType":"7","secType_des":"Commercial Paper","sec_order":"5","name":"Money Market Instruments","color":"#cdcc34"},{"secType":"8","secType_des":"Step Discount Bond","sec_order":"4","name":"Corporate Bonds","color":"#055ba5"},{"secType":"9","secType_des":"Regular Return Bond","sec_order":"4","name":"Corporate Bonds","color":"#055ba5"},{"secType":"10","secType_des":"Certificate Of Deposit","sec_order":"5","name":"Money Market Instruments","color":"#cdcc34"},{"secType":"11","secType_des":"Securitized Instruments","sec_order":"6","name":"Securitized Instruments","color":"#ffc49a"},{"secType":"12","secType_des":"Debentures","sec_order":"4","name":"Corporate Bonds","color":"#055ba5"},{"secType":"13","secType_des":"Units","sec_order":"3","name":"Mutual Funds","color":"#10c782"},{"secType":"14","secType_des":"Government Securities","sec_order":"7","name":"Government Securities","color":"#1cc4cc"},{"secType":"15","secType_des":"Warrants","sec_order":"1","name":"Equity","color":"#fdc12a"},{"secType":"16","secType_des":"Commodity","sec_order":"10","name":"Commodity","color":"#ffff00"},{"secType":"17","secType_des":"RBI Relief Bonds","sec_order":"7","name":"Government Securities","color":"#1cc4cc"},{"secType":"18","secType_des":"Rights Entitlement","sec_order":"1","name":"Equity","color":"#fdc12a"},{"secType":"19","secType_des":"Indian Depository Receipt","sec_order":"1","name":"Equity","color":"#fdc12a"},{"secType":"20","secType_des":"Mutual Fund Trace","sec_order":"3","name":"Mutual Funds","color":"#10c782"},{"secType":"21","secType_des":"Alternative Investment Fund","sec_order":"3","name":"Mutual Funds","color":"#10c782"},{"secType":"22","secType_des":"Treasury Bill","sec_order":"5","name":"Money Market Instruments","color":"#cdcc34"}]}';

/* portfolio response*/


var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
                  ];

var change_value = function(a,b)
{
    var c = a - b;
    return c;
}
var change_value_percentage = function(e,f)
{
    var x = ( e / f ) * 100;
    return x;
}

function portfolio_paid()
{
    if( JSON.parse(localStorage.getItem('RTO')) == "RequestTimeOut" )
    {
        $(".portfolio_success").hide();
        $(".portfolio_error").show();
        $("#loading_p").html("");
        $("#loading_p").html("The request timed out");
        $(".refresh_soh").show();
        return false;
    }
    else{
        if(JSON.parse(localStorage.getItem('hidemenu')) == "yes"){
            $(".SlideMenu").hide();
            $(".overlay_user").hide();
            $('.slide-in').toggleClass('on');
            $('.main_wrapper').toggleClass('on');
            outIn = 'in';
            
        }
        else{
            $('.slide-in').toggleClass('on');
            $('.main_wrapper').toggleClass('on');
            setTimeout(function(){
                       $('.slide-in').toggleClass('on');
                       $('.main_wrapper').toggleClass('on');
                       $(".overlay_user").hide();
                       outIn = 'in';
                       }, 3000);
            
        }
        
        var equity = 0;var pre_share = 0;var mutual_fund = 0;var bonds = 0;var money_market = 0;var Securitized = 0;var gov_sec = 0;var postal_saving = 0; var commodity = 0;var prev_total = 0;
        
        var equity_prev = 0;var pre_share_prev = 0;var mutual_fund_prev = 0;var bonds_prev = 0;var money_market_prev = 0;var Securitized_prev = 0;var gov_sec_prev = 0;var postal_saving_prev = 0; var commodity_prev = 0;
        
        var change_equity;var change_pre_share;var change_mutual_fund;var change_bonds;var change_money_market;var change_Securitized;var change_gov_sec;var change_postal_saving; var change_commodity;
        
        var user_id = JSON.parse(localStorage.getItem('temp_userId'));
        var dp_id = JSON.parse(localStorage.getItem('temp_dpid'));
        var client_id = JSON.parse(localStorage.getItem('temp_clientId'));
        var data = JSON.parse(localStorage.getItem('portfolio_data'));
        
        var result = $.parseJSON(data);console.log(data);
        // $("li #mPortFolio").show();
        
        if(result.status == "F"){
            
            $(".portfolio_success").hide();
            $(".portfolio_error").show();
            $("#loading_p").html("");
            $("#loading_p").html(result.errorDescription);
            $(".refresh_soh").show();
            
            
        }
        
        else
        {
            $(".portfolio_success").show();
            $(".portfolio_error").hide();
            var result_portfolio = $.parseJSON(security_order);
            var portfolio_temp = result.normalHoldingsList;
            var security_temp = result_portfolio.portfolio;
            // LastFileCreation date
            var NSETimeOfLastFileCreation = result.NSETimeOfLastFileCreation;
            var split_date = NSETimeOfLastFileCreation.split("-");
            var split_hr = split_date[2].split(" ");
            var mon = monthNames[split_date[1]-1];
            var split_hr_min = split_hr[1].split(":");
            var currentServerTimeStamp = split_hr[0] + " " + mon + "," + split_date[0] + "| "+split_hr_min[0]+":"+split_hr_min[1];
            localStorage.setItem('currentServerTimeStamp', JSON.stringify(currentServerTimeStamp));
            // PreviousDayLastCreationTime date
            var NSEPreviousDayLastCreationTime = result.NSEPreviousDayLastCreationTime;
            var split_pdate = NSEPreviousDayLastCreationTime.split("-");
            var split_phr = split_pdate[2].split(" ");
            var mon = monthNames[split_pdate[1]-1];
            var split_phr_pmin = split_phr[1].split(":");
            var PreviousDay = split_phr[0] + " " + mon + "," + split_pdate[0] + "| "+split_phr_pmin[0]+":"+split_phr_pmin[1];
            $("#portfolio_holding_dt").html("<div>As ON</div><div style='color:#ababab;'>"+currentServerTimeStamp+"</div>");
            $("#prev_value_dt").html("<div>As ON</div><div>"+PreviousDay+"</div>");
            $("#portfolio_holding").html(number_format(FixedNum(result.totalValueOfHoldings)));
            for(var j =0;j<portfolio_temp.length ;j++){
                
                for(var p =0;p<security_temp.length ;p++){
                    if(portfolio_temp[j].secGroup == security_temp[p].sec_order){
                        portfolio_sec_type.push(security_temp[p].sec_order);
                    }
                    else{
                        console.log("running..");
                    }
                }
                
            }
            
            var unique=portfolio_sec_type.filter(function(itm,i,portfolio_sec_type){
                                                 return i==portfolio_sec_type.indexOf(itm);
                                                 
                                                 });
            
            console.log(unique.sort());
            
            //console.log(equity);
            for(var i =0;i<portfolio_temp.length ;i++){
                prev_total += (portfolio_temp[i].prevDayMktPrice * portfolio_temp[i].qty);
                if(portfolio_temp[i].secGroup == "1"){
                    equity += parseFloat(portfolio_temp[i].currentIsinLevelHolding);
                    equity_prev += (portfolio_temp[i].prevDayMktPrice * portfolio_temp[i].qty);
                    
                }
                else if(portfolio_temp[i].secGroup == "2"){
                    pre_share += parseFloat(portfolio_temp[i].currentIsinLevelHolding);
                    pre_share_prev += (portfolio_temp[i].prevDayMktPrice * portfolio_temp[i].qty);
                    
                }
                else if(portfolio_temp[i].secGroup == "3"){
                    mutual_fund += parseFloat(portfolio_temp[i].currentIsinLevelHolding);
                    mutual_fund_prev += (portfolio_temp[i].prevDayMktPrice * portfolio_temp[i].qty);
                    
                }
                else if(portfolio_temp[i].secGroup == "4"){
                    bonds += parseFloat(portfolio_temp[i].currentIsinLevelHolding);
                    bonds_prev += (portfolio_temp[i].prevDayMktPrice * portfolio_temp[i].qty);
                    
                }
                else if(portfolio_temp[i].secGroup == "5"){
                    money_market += parseFloat(portfolio_temp[i].currentIsinLevelHolding);
                    money_market_prev += (portfolio_temp[i].prevDayMktPrice * portfolio_temp[i].qty);
                    
                }
                else if(portfolio_temp[i].secGroup == "6"){
                    Securitized += parseFloat(portfolio_temp[i].currentIsinLevelHolding);
                    Securitized_prev += (portfolio_temp[i].prevDayMktPrice * portfolio_temp[i].qty);
                    
                }
                else if(portfolio_temp[i].secGroup == "7"){
                    gov_sec += parseFloat(portfolio_temp[i].currentIsinLevelHolding);
                    gov_sec_prev += (portfolio_temp[i].prevDayMktPrice * portfolio_temp[i].qty);
                    
                }
                else if(portfolio_temp[i].secGroup == "8"){
                    postal_saving += parseFloat(portfolio_temp[i].currentIsinLevelHolding);
                    postal_saving_prev += (portfolio_temp[i].prevDayMktPrice * portfolio_temp[i].qty);
                    
                }
                else if(portfolio_temp[i].secGroup == "10"){
                    commodity += parseFloat(portfolio_temp[i].currentIsinLevelHolding);
                    commodity_prev += (portfolio_temp[i].prevDayMktPrice * portfolio_temp[i].qty);
                    
                }
                else{
                    console.log("running..");
                }
                
            }
            
            $("#prev_value").html(("<div>"+number_format(FixedNum(prev_total))+"</div>"));
            
            var change_previous_total = FixedNum(result.totalValueOfHoldings - prev_total);
            var change_high_low = change_color(change_previous_total);//get color for high or low value
            var get_image_path = change_image(change_previous_total);
            
            var ignore_sign = Math.abs(change_previous_total);
            var change_previous_per = FixedNum((ignore_sign/result.totalValueOfHoldings) * 100);
            
            $("#total_business_value").html('<table width="100%" border="0"align="center" cellpadding="0" cellspacing="0" style="border-collapse:collapse;"><tr><td style="padding-left:5px;" width="3%"><img src='+get_image_path+' class="arrow"/></td><td width="70%" style="color:'+change_high_low+';vertical-align:middle;">'+number_format_s(ignore_sign)+'('+change_previous_per+'%)</td><td class="refresh_icon" onclick="portfolio_refresh();" id="refresh_portfolio" style="padding-right:10px;" align="right" valign="left"></td></tr>');
            
            console.log(equity_prev);console.log(commodity_prev);console.log(postal_saving_prev);console.log(gov_sec_prev);console.log(Securitized_prev);console.log(money_market_prev);console.log(bonds_prev);console.log(mutual_fund_prev);console.log(pre_share_prev);
            console.log(equity_prev);
            $(".portfolio_type").append('<table border="0" cellspacing="0" cellpadding="0" width="100%" id="portfolio_list" style="color:#fff;"></table>');
            for(var i = 0;i<unique.length;i++){
                
                if(unique[i] == "1"){
                    //if(equity != 0){
                    var equity_v = number_format(FixedNum(equity));//current holding
                    change_equity = FixedNum(equity - equity_prev);console.log(change_equity); //previous holding
                    var class_g_r1 = change_color(change_equity); //change green or red color
                    var get_img_whitepath = white_image(change_equity);
                    var ch_eq = Math.abs(change_equity); // getting positive value irrespective of sign
                    var change_per1 = FixedNum((ch_eq/equity)*100);console.log(change_per1); // percentage
                    $("#portfolio_list").append('<tr class="rlabel '+class_g_r1+'" style="background-color:#fdc12a;" id="1" onclick="paid_portfolio(this.id);"><td width="100" height= "40" align="left" valign="left" style="padding-left:5px;"><div><b>Equity</div><div>'+equity_v+'</b></div></td><td width="100" align="right" valign="left" style="background-color:'+class_g_r1+';padding-right:5px;"><div><img src='+get_img_whitepath+' class="arrow" style="float:left;margin-top:15%;"/>CHANGE</div><div><b>'+number_format(ch_eq)+'</b></div><div>('+change_per1+'%)</div></td></tr>');
                    //}
                    /*else
                     {
                     console.log("no data");
                     }*/
                }
                
                else if(unique[i] == "2"){
                    // if(pre_share != 0){
                    var pre_share_v = number_format(FixedNum(pre_share));
                    change_pre_share = FixedNum(pre_share - pre_share_prev);console.log(change_pre_share);
                    var get_img_whitepath = white_image(change_pre_share);
                    var class_g_r2 = change_color(change_pre_share);
                    var pre_sh = Math.abs(change_pre_share);
                    var change_per2 = FixedNum((pre_sh/pre_share)*100);console.log(change_per2);
                    $("#portfolio_list").append('<tr class="rlabel '+class_g_r2+'" style="background-color:#caadff;" id="2" onclick="paid_portfolio(this.id);"><td width="100" height= "40" align="left" valign="left" style="padding-left:5px;"><div><b>Preference Shares</div><div>'+pre_share_v+'</b></div></td><td width="100" align="right" valign="right" style="background-color:'+class_g_r2+';padding-right:5px;"><div><img src='+get_img_whitepath+' class="arrow" style="float:left;margin-top:15%;"/>CHANGE</div><div><b>'+number_format(pre_sh)+'</b></div><div>('+change_per2+'%)</div></td></tr>');
                    // }
                    /*  else
                     {
                     console.log("no data");
                     }*/
                    
                }
                else if(unique[i] == "3"){
                    // if(mutual_fund != 0 ){
                    var mutual_fund_v = number_format(FixedNum(mutual_fund));
                    change_mutual_fund = FixedNum(mutual_fund - mutual_fund_prev);console.log(change_mutual_fund);
                    var get_img_whitepath = white_image(change_mutual_fund);
                    var class_g_r3 = change_color(change_mutual_fund);
                    var mu_funds = Math.abs(change_mutual_fund);
                    var change_per3 = FixedNum((mu_funds/mutual_fund)*100);console.log(change_per3);
                    $("#portfolio_list").append('<tr class="rlabel '+class_g_r3+'" style="background-color:#10c782;" id="3" onclick="paid_portfolio(this.id);"><td width="100" height= "40" align="left" valign="left" style="padding-left:5px;"><div><b>Mutual Funds</div><div>'+mutual_fund_v+'</b></div></td><td width="100" align="right" valign="right" style="background-color:'+class_g_r3+';padding-right:5px;"><div><img src='+get_img_whitepath+' class="arrow" style="float:left;margin-top:15%;"/>CHANGE</div><div><b>'+number_format(mu_funds)+'</b></div><div>('+change_per3+'%)</div></td></tr>');
                    //  }
                    /* else
                     {
                     console.log("no data");
                     }*/
                }
                else if(unique[i] == "4"){
                    // if(bonds != 0){
                    var bonds_v = number_format(FixedNum(bonds));
                    change_bonds = FixedNum(bonds - bonds_prev);console.log(change_bonds);
                    var get_img_whitepath = white_image(change_bonds);
                    var class_g_r4 = change_color(change_bonds);
                    var bonds_s = Math.abs(change_bonds);
                    var change_per4 = FixedNum((bonds_s/bonds)*100);console.log(change_per4);
                    $("#portfolio_list").append('<tr class="rlabel '+class_g_r4+'" style="background-color:#055ba5;" id="4" onclick="paid_portfolio(this.id);"><td width="100" height= "40" align="left" valign="left" style="padding-left:5px;"><div><b>Corporate Bonds</div><div>'+bonds_v+'</b></div></td><td width="100" align="right" valign="right" style="background-color:'+class_g_r4+';padding-right:5px;"><div><img src='+get_img_whitepath+' class="arrow" style="float:left;margin-top:15%;"/>CHANGE</div><div>'+number_format(bonds_s)+'</div><div>('+change_per4+'%)</div></td></tr>');
                    //}
                    /* else
                     {
                     console.log("no data");
                     }*/
                }
                else if(unique[i] == "5"){
                    // if(money_market != 0){
                    var money_market_v = number_format(FixedNum(money_market));
                    change_money_market = FixedNum(money_market - money_market_prev);console.log(change_money_market);
                    var get_img_whitepath = white_image(change_money_market);
                    var class_g_r5 = change_color(change_money_market);
                    var mo_mrkt = Math.abs(change_money_market);
                    var change_per5 = FixedNum((mo_mrkt/money_market)*100);console.log(change_per5);
                    $("#portfolio_list").append('<tr class="rlabel '+class_g_r5+'" style="background-color:#cdcc34;" id="5" onclick="paid_portfolio(this.id);"><td width="100" height= "40" align="left" valign="left" style="padding-left:5px;"><div><b>Money Market Instruments</div><div>'+money_market_v+'</b></div></td><td width="100" align="right" valign="right" style="background-color:'+class_g_r5+';padding-right:5px;"><div><img src='+get_img_whitepath+' class="arrow" style="float:left;margin-top:15%;"/>CHANGE</div><div><b>'+number_format(mo_mrkt)+'</b></div><div>('+change_per5+'%)</div></td></tr>');
                    //}
                    /* else
                     {
                     console.log("no data..");
                     }*/
                }
                else if(unique[i] == "6"){
                    //if(Securitized != 0){
                    var Securitized_v = number_format(FixedNum(Securitized));
                    change_Securitized = FixedNum(Securitized - Securitized_prev);console.log(change_Securitized);
                    var get_img_whitepath = white_image(change_Securitized);
                    var class_g_r6 = change_color(change_Securitized);
                    var Securitized_s = Math.abs(change_Securitized);
                    var change_per6 = FixedNum((Securitized_s/Securitized)*100);console.log(change_per6);
                    $("#portfolio_list").append('<tr class="rlabel '+class_g_r6+'" style="background-color:#ffc49a;" id="6" onclick="paid_portfolio(this.id);"><td width="100" height= "40" align="left" valign="left" style="padding-left:5px;"><div><b>Securitized Instruments</div><div>'+Securitized_v+'</b></div></td><td width="100" align="right" valign="right" style="background-color:'+class_g_r6+';padding-right:5px;"><div><img src='+get_img_whitepath+' class="arrow" style="float:left;margin-top:15%;"/>CHANGE</div><div><b>'+number_format(Securitized_s)+'</b></div><div>('+change_per6+'%)</div></td></tr>');
                    // }
                    /* else
                     {
                     console.log("no data..");
                     }*/
                }
                else if(unique[i] == "7"){
                    //if(gov_sec != 0){
                    var gov_sec_v = number_format(FixedNum(gov_sec));
                    change_gov_sec = FixedNum(gov_sec - gov_sec_prev);console.log(change_gov_sec);
                    var get_img_whitepath = white_image(change_gov_sec);
                    var class_g_r7 = change_color(change_gov_sec);console.log(class_g_r7);
                    var govn = Math.abs(change_gov_sec);
                    var change_per7 = FixedNum((govn/gov_sec)*100);console.log(change_per7);
                    $("#portfolio_list").append('<tr class="rlabel '+class_g_r7+'" style="background-color:#1cc4cc;" id="7" onclick="paid_portfolio(this.id);"><td width="100" height= "40" align="left" valign="left" style="padding-left:5px;"><div><b>Government Securities</div><div>'+gov_sec_v+'</b></div></td><td height= "40" width="100" align="right" valign="right" style="background-color:'+class_g_r7+';padding-right:5px;"><div><img src='+get_img_whitepath+' class="arrow" style="float:left;margin-top:15%;"/>CHANGE</div><div><b>'+number_format(govn)+'</b></div><div>('+change_per7+'%)</div></td></tr>');
                    // }
                    /*  else
                     {
                     console.log("no data..");
                     }*/
                }
                else if(unique[i] == "8"){
                    //if(postal_saving != 0){
                    var postal_saving_v = number_format(FixedNum(postal_saving));
                    change_postal_saving = FixedNum(postal_saving - postal_saving_prev);console.log(change_postal_saving);
                    var get_img_whitepath = white_image(change_postal_saving);
                    var class_g_r8 = change_color(change_postal_saving);
                    var pos_sav = Math.abs(change_postal_saving);
                    var change_per8 = FixedNum((pos_sav/postal_saving)*100);console.log(change_per8);
                    $("#portfolio_list").append('<tr class="rlabel '+class_g_r8+'" style="background-color:#6600cd;" id="8" onclick="paid_portfolio(this.id);"><td width="100" height= "40" align="left" valign="left" style="padding-left:5px;"><div><b>Postal Saving Scheme</div><div>'+postal_saving_v+'</b></div></td><td width="100" align="right" valign="right" style="background-color:'+class_g_r8+';padding-right:5px;"><div><img src='+get_img_whitepath+' class="arrow" style="float:left;margin-top:15%;"/>CHANGE</div><div><b>'+number_format(pos_sav)+'</b></div><div>('+change_per8+'%)</div></td></tr>');
                    //}
                    /*  else
                     {
                     console.log("no data..");
                     }*/
                    
                }
                else{
                    // if(commodity != 0){
                    var commodity_v = number_format(FixedNum(commodity));
                    change_commodity = FixedNum(commodity - commodity_prev);console.log(change_commodity);
                    var get_img_whitepath = white_image(change_commodity);
                    var class_g_r9 = change_color(change_commodity);
                    var comm = Math.abs(change_commodity);
                    var change_per9 = FixedNum((comm/commodity)*100);console.log(change_per9);
                    $("#portfolio_list").append('<tr class="rlabel '+class_g_r9+'" style="background-color:#ffff00;" id="9" onclick="paid_portfolio(this.id);"><td width="100" height= "40" align="left" valign="left" style="padding-left:5px;"><div><b>Commodity</div><div>'+commodity_v+'</b></div></td><td width="100" align="right" valign="right" style="background-color:'+class_g_r9+';padding-right:5px;"><div><img src='+get_img_whitepath+' class="arrow" style="float:left;margin-top:15%;"/>CHANGE</div><div><b>'+number_format(comm)+'</b></div><div>('+change_per9+'%)</div></td></tr>');
                    // }
                    /* else
                     {
                     console.log("no data..");
                     }*/
                    
                }
                
            }//end of for loop
            //chart
            var p_2003 = JSON.parse(localStorage.getItem('paid_2003'));
            
            var barc_result = $.parseJSON(p_2003);console.log(p_2003);
            if(barc_result.status == "F"){
                $(".portfolio_wrap").hide();
                $(".portfolio_wrap_error").show();
                $("#loading").html("");
                $("#loading").html(barc_result.errorDescription);
                
            }
            else{
                $(".portfolio_wrap").show();
                $(".portfolio_wrap_error").hide();
                var array = [];
                var barc_temp = barc_result.Holdings;
                var barc_month = [];barc_month.length = 0;
                var barc_holding = [];barc_holding.length = 0;
                for(var i = 0;i < barc_temp.length;i++){
                    var newMonth = (barc_temp[i].month).split('-').reverse().join('-00-');
                    array.push({
                               Mdate : newMonth,
                               Mhold : barc_temp[i].holdings
                               });
                    //barc_holding.push(FixedNum(barc_temp[i].holdings));
                    //alert(array);
                }
                var sorted = array.sort(function (a, b) {
                                        var reg = /-/; //The regex on which matches the string should be split (any used delimiter) -> could also be written like /[.:T\+]/
                                        var parsed = [ //an array which holds the date parts for a and b
                                                      a.Mdate.split(reg), //Split the datestring by the regex to get an array like [Year,Month,Day,Hour,...]
                                                      b.Mdate.split(reg)
                                                      ];
                                        var array = [ //Create an array of dates for a and b
                                                     new Date(parsed[0][0], parsed[0][1], parsed[0][2]),//Constructs an date of the above parsed parts (Year,Month...
                                                     new Date(parsed[1][0], parsed[1][1], parsed[1][2])
                                                     ];
                                        return array[0] - array[1]; //Returns the difference between the date (if b > a then a - b < 0)
                                        });
                $.each(sorted, function (index, value) {
                       barc_month.push(value.Mdate);
                       barc_holding.push(FixedNum(value.Mhold));
                       });
                var first = barc_month[0];
                var last = barc_month[barc_month.length - 1];
                var date1_s = first.split('-00-');
                var date2_s = last.split('-00-');
                var start_mon = monthNames[date1_s[1]-1];
                var end_mon = monthNames[date2_s[1]-1];
                var label_dt1 = start_mon+" "+date1_s[0];
                var label_dt2 = end_mon+" "+date2_s[0];
                $("#first_month").html(label_dt1);$("#last_month").html(label_dt2);
                var randomScalingFactor = function(){ return Math.round(Math.random()*100)};
                
                var barChartData = {
                    labels : ["","","","","","","","","","","","",""],
                    datasets : [
                                {
                                fillColor : "rgba(19,194,124,1)",
                                strokeColor : "rgba(19,194,124,0.8)",
                                highlightFill: "rgba(19,194,124,0.75)",
                                highlightStroke: "rgba(19,194,124,1)",
                                //data : [12000, 24000, 24200, 22700, 6400, 20300, 7300,6800, 6800, 10500, 18000, 24000, 40]
                                data : barc_holding
                                }
                                ]
                    
                }
                var month1 = barc_holding[barc_holding.length - 1];
                var month3 = barc_holding[barc_holding.length - 3];
                var month6 = barc_holding[barc_holding.length - 6];
                var last_month1_per = infinite_val(FixedNum(((result.totalValueOfHoldings - month1)/month1)*100));
                var last_month3_per = infinite_val(FixedNum(((result.totalValueOfHoldings - month3)/month3)*100));
                var last_month6_per = infinite_val(FixedNum(((result.totalValueOfHoldings - month6)/month6)*100));
                
                var color1 = change_color(last_month1_per);
                var color3 = change_color(last_month3_per);
                var color6 = change_color(last_month6_per);
                $("#month1").html('<p style="color:'+color1+';margin-top:-6px;">'+last_month1_per+'%</p>');
                $("#month3").html('<p style="color:'+color3+';margin-top:-6px;">'+last_month3_per+'%</p>');
                $("#month6").html('<p style="color:'+color6+';margin-top:-6px;">'+last_month6_per+'%</p>');
                
                
                var ctx = document.getElementById("canvas").getContext("2d");
                window.myBar = new Chart(ctx).Bar(barChartData, {
                                                  responsive : true
                                                  });
            }
            
            
            
        }//end of else
        db = window.sqlitePlugin.openDatabase({name: "NSDL_ISIN.db"});
        db.transaction(createDB,errorCB,successCB);
        
    }
   
    $("#account_status_u").html(": "+JSON.parse(localStorage.getItem('acc_status')));
    
   
}

var g;
function paid_portfolio(id){
    $("#backg").css("display", "block");
    localStorage.setItem('p_id', JSON.stringify(id));
    var store_value1 = $("#"+id).each(function () {
                                      g1 = $(this).attr('class');
                                      g = $(this).find("div").map(function (index, val) {
                                                                               return $(this).text();
                                                                               }).toArray();
                                      
                                    });
    console.log(g1);
    var paid_isin_color = g1.split(" ");
    localStorage.setItem('isin_color', JSON.stringify(paid_isin_color[1]));
    localStorage.setItem('table_array', JSON.stringify(g));
    //["Equities", "17,06,150.00", "change", "7,600.00", "0.45%"]
    window.open("paid_portfolio.html",'_self',false);
   
    
}
function paid_load(){
    var arrow_path;
    var data = JSON.parse(localStorage.getItem('portfolio_data'));
    console.log(data);
    var result = $.parseJSON(data);console.log(result.status);
    var result_portfolio = $.parseJSON(security_order);
    var portfolio_temp = result.normalHoldingsList;
    var global_paid_id =JSON.parse(localStorage.getItem('p_id'));
    var table_array =JSON.parse(localStorage.getItem('table_array'));
    var result_portfolio = $.parseJSON(security_order);
    var security_temp = result_portfolio.portfolio;
    var isin_change_color = JSON.parse(localStorage.getItem('isin_color'));
    if(isin_change_color == "#139e15"){
        arrow_path = "img/green.png";
    }
    else{
        
        arrow_path = "img/red.png";
        
    }
    console.log(table_array);
    var soh_date = JSON.parse(localStorage.getItem('currentServerTimeStamp'));
    $("#secType_name").html("");$("#totalValueOffield").html("");$("#portfolio_table").html("");$("#p_title").html("");$("#portfolio_header").html("");
    
    //append header body
    for(var i=0;i<security_temp.length;i++){
        if(security_temp[i].sec_order == global_paid_id){
            
            $("#p_title").html("<b>"+security_temp[i].name+"</b>");
            
            $("#portfolio_header").html('<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" style="border-collapse: collapse;background-color:'+security_temp[i].color+';color:#fff;height:150px;"><tr><td align="left" valign="left" style="color:#fff;padding-top:5px;padding-left:5px;font-family:DroidSans-Bold;" colspan="3"><p class="p_4">'+security_temp[i].name+'</p></td><tr><td style="padding-left:5px;font-family:DroidSans-Bold;"><p class="p_4">'+table_array[1]+'</p></td><td>&nbsp;&nbsp;</td><td align="right" valign="middle" style="padding-top:5px;padding-right:5px;color:#fff;"><p class="p_4">CHANGE</p></td></tr><tr><td align="center" valign="middle" colspan="2"><img src='+arrow_path+' class="arrow" style="margin-left:20px;"/></td><td width="10%" align="right" valign="right" style="padding-right:5px;"><p class="p_4" style="color:'+isin_change_color+';font-family:DroidSans-Bold;">'+table_array[3]+'</p></td></tr><tr><td colspan="2"><p class="p_4">&nbsp;</p></td><td width="10%" align="right" valign="right" style="padding-right:5px;"><p style="color:'+isin_change_color+';margin:0;" class="p_4">'+table_array[4]+'</p></td></tr><tr><td style="color:#000;padding-left:5px;"><p class="p_4">STATEMENT OF HOLDING</p><p style="color:#000;font-weight: normal;font-style: normal;font-family: DroidSans;" class="p_4">as on '+soh_date+'</p></td><td><p class="p_4">&nbsp;</p></td><td align="right" valign="middle" class="refresh_icon" onclick="single_portfolio();" style="padding-right:5px;"></td></tr></table>');
            
         
        }
        
    }
    
  //  $("#totalValueOffield").html(number_format(equity));
    //append ISIN BODY
    for(var i =0;i<portfolio_temp.length ;i++){
        
        if(portfolio_temp[i].secGroup == global_paid_id){
            var change_value = FixedNum(portfolio_temp[i].currentIsinLevelHolding - (portfolio_temp[i].prevDayMktPrice * portfolio_temp[i].qty));
            var text_color = change_color(change_value);
            var absolute_change_value = change_value;
           
            var change_value_per = FixedNum((change_value/portfolio_temp[i].currentIsinLevelHolding)*100);
            var text_color_per = change_color(change_value_per);
            var days_change_per = number_format_s(FixedNum(((portfolio_temp[i].currentMktPrice - portfolio_temp[i].prevDayMktPrice)/portfolio_temp[i].prevDayMktPrice)*100));
            var text_color_day = change_color(days_change_per);
            var days_per = number_format_s(days_change_per);
           $("#portfolio_table").append('<table class="'+text_color_per+' eq_table eq_table_list content_wrap" border="0" width="100%" id="'+portfolio_temp[i].isin+'" onclick="call_2002(this.id);"><tr><td width="33%" align="left" valign="left" style="padding-left:5px;"><div>'+portfolio_temp[i].isinName+'</div><div style="color:#edc218;">'+portfolio_temp[i].isin+'</div><div>'+portfolio_temp[i].isinLastTrnDate+'</div></td><td width="33%" align="center" valign="left"><div style="color:'+text_color+';">'+number_format_s(absolute_change_value)+'</div><div>'+number_format_s(portfolio_temp[i].currentMktPrice)+'</div><div>'+number_format_s(portfolio_temp[i].qty)+'</div></td><td width="33%" align="right" valign="right" style="padding-right:5px;"><div>'+number_format_s(portfolio_temp[i].currentIsinLevelHolding)+'</div><div>'+number_format_s(FixedNum(portfolio_temp[i].prevDayMktPrice * portfolio_temp[i].qty))+'</div><div style="color:'+text_color_day+';">'+number_format_s(FixedNum(portfolio_temp[i].currentMktPrice - portfolio_temp[i].prevDayMktPrice))+'('+days_change_per+'%)</div></td></tr><tr class="soh_label"><td width="100" align="right" valign="right" colspan="3"><img src="img/back_button.png" style="float:right;"/></td></tr></table>');
        }
        else{
            console.log("no data...");
            
        }
    }
    
    
}
function single_portfolio(){
    $("#backg").css("display", "block");
    //window.open("paid_portfolio.html","_self",false);
    setTimeout(function(){
               var user_id = JSON.parse(localStorage.getItem('temp_userId1'));
               var dp_id = JSON.parse(localStorage.getItem('temp_dpid1'));
               var client_id = JSON.parse(localStorage.getItem('temp_clientId1'));
               var portfolio_url = base_url+'&userId='+user_id+'&functionId=2001&dpId='+dp_id+'&clientId='+client_id+'';
               var data = global_ajax(portfolio_url);
               console.log(data);
               var result = $.parseJSON(data);
               console.log(data);
               var portfolio_data = data;
               localStorage.setItem('portfolio_data', JSON.stringify(portfolio_data));
               if(result.status == "S")
               {
               // LastFileCreation date
               var NSETimeOfLastFileCreation = result.NSETimeOfLastFileCreation;
               var split_date = NSETimeOfLastFileCreation.split("-");
               var split_hr = split_date[2].split(" ");
               var mon = monthNames[split_date[1]-1];
               var split_hr_min = split_hr[1].split(":");
               var currentServerTimeStamp = split_hr[0] + " " + mon + "," + split_date[0] + " | "+split_hr_min[0]+":"+split_hr_min[1];
               
               var arrow_path;
               var result_portfolio = $.parseJSON(security_order);
               var portfolio_temp = result.normalHoldingsList;
               var global_paid_id =JSON.parse(localStorage.getItem('p_id'));
               var table_array =JSON.parse(localStorage.getItem('table_array'));
               var result_portfolio = $.parseJSON(security_order);
               var security_temp = result_portfolio.portfolio;
               var isin_change_color = JSON.parse(localStorage.getItem('isin_color'));
               if(isin_change_color == "#139e15"){
               arrow_path = "img/green.png";
               }
               else{
               
               arrow_path = "img/red.png";
               
               }
               console.log(table_array);
               $("#secType_name").html("");$("#totalValueOffield").html("");$("#portfolio_table").html("");$("#p_title").html("");$("#portfolio_header").html("");
               
               //append header body
               for(var i=0;i<security_temp.length;i++){
               if(security_temp[i].sec_order == global_paid_id){
               
               $("#p_title").html("<b>"+security_temp[i].name+"</b>");
               
               $("#portfolio_header").html('<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" style="border-collapse: collapse;background-color:'+security_temp[i].color+';color:#fff;height:150px;"><tr><td align="left" valign="left" style="color:#fff;padding-top:5px;padding-left:5px;" colspan="3"><p class="p_4">'+security_temp[i].name+'</p></td><tr><td style="padding-left:5px;"><p class="p_4">'+table_array[1]+'</p></td><td>&nbsp;&nbsp;</td><td align="right" valign="middle" style="padding-top:5px;padding-right:5px;color:#fff;"><p class="p_4">CHANGE</p></td></tr><tr><td align="center" valign="middle" colspan="2"><img src='+arrow_path+' class="arrow" style="margin-left:20px;"/></td><td width="10%" align="right" valign="right" style="padding-right:5px;"><p class="p_4" style="color:'+isin_change_color+';">'+table_array[3]+'</p></td></tr><tr><td colspan="2"><p class="p_4">&nbsp;</p></td><td width="10%" align="right" valign="right" style="padding-right:5px;"><p style="color:'+isin_change_color+';margin:0;" class="p_4">'+table_array[4]+'</p></td></tr><tr><td style="color:#000;padding-left:5px;"><p class="p_4">STATEMENT OF HOLDING</p><p style="color:#000;font-weight: normal;font-style: normal;font-family: DroidSans;" class="p_4">as on '+currentServerTimeStamp+'</p></td><td><p class="p_4">&nbsp;</p></td><td align="right" valign="middle" class="refresh_icon" onclick="single_portfolio();" style="padding-right:5px;"></td></tr></table>');
               
               
               }
               
               }
               
               //  $("#totalValueOffield").html(number_format(equity));
               //append ISIN BODY
               for(var i =0;i<portfolio_temp.length ;i++){
               
               if(portfolio_temp[i].secGroup == global_paid_id){
               var change_value = FixedNum(portfolio_temp[i].currentIsinLevelHolding - (portfolio_temp[i].prevDayMktPrice * portfolio_temp[i].qty));
               var text_color = change_color(change_value);
               var absolute_change_value = change_value;
               
               var change_value_per = FixedNum((change_value/portfolio_temp[i].currentIsinLevelHolding)*100);
               var text_color_per = change_color(change_value_per);
               var days_change_per = number_format_s(FixedNum(((portfolio_temp[i].currentMktPrice - portfolio_temp[i].prevDayMktPrice)/portfolio_temp[i].prevDayMktPrice)*100));
               var text_color_day = change_color(days_change_per);
               var days_per = number_format_s(days_change_per);
               $("#portfolio_table").append('<table class="'+text_color_per+' eq_table eq_table_list content_wrap" border="0" width="100%" id="'+portfolio_temp[i].isin+'" onclick="call_2002(this.id);"><tr><td width="33%" align="left" valign="left" style="padding-left:5px;"><div>'+portfolio_temp[i].isinName+'</div><div style="color:#edc218;">'+portfolio_temp[i].isin+'</div><div>'+portfolio_temp[i].isinLastTrnDate+'</div></td><td width="33%" align="center" valign="left"><div style="color:'+text_color+';">'+number_format_s(absolute_change_value)+'</div><div>'+number_format_s(portfolio_temp[i].currentMktPrice)+'</div><div>'+number_format_s(portfolio_temp[i].qty)+'</div></td><td width="33%" align="right" valign="right" style="padding-right:5px;"><div>'+number_format_s(portfolio_temp[i].currentIsinLevelHolding)+'</div><div>'+number_format_s(FixedNum(portfolio_temp[i].prevDayMktPrice * portfolio_temp[i].qty))+'</div><div style="color:'+text_color_day+';">'+number_format_s(FixedNum(portfolio_temp[i].currentMktPrice - portfolio_temp[i].prevDayMktPrice))+'('+days_change_per+'%)</div></td></tr><tr class="soh_label"><td width="100" align="right" valign="right" colspan="3"><img src="img/back_button.png" style="float:right;"/></td></tr></table>');
               }
               else{
               console.log("no data...");
               
               }
               }
               $("#backg").css("display", "none");
               }
               else{
               $("#backg").css("display", "none");
               swal({
                    title: " ",
                    text: result.errorDescription
                    },
                    function(){
                    return false
                    });
               }
               
               },100);
}

//var result = $.parseJSON(portfolio_2002);
//var get_data = result.isinWiseList;



var isin_2002;var isin_2002_color;
function call_2002(id){
    var store_value1 = $("#"+id).each(function () {
                                      isin_2002_color = $(this).attr('class');
                                      isin_2002 = $(this).find("div").map(function (index, val) {
                                                                          return $(this).text();
                                                                          }).toArray();
                                      
                                      });
    var d = new Date();  //timestamp
    
    var da = d.getDate();//day
    var mon = d.getMonth()+1;   //month
    var yr = d.getFullYear();   //year
    var current_dt = yr+"-"+mon+"-"+da;
    console.log(isin_2002_color);console.log(isin_2002);
    var color_isin_2002 = isin_2002_color.split(" ");
    localStorage.setItem('single_isin_color', JSON.stringify(color_isin_2002[0]));
    localStorage.setItem('table_isin', JSON.stringify(isin_2002));
    localStorage.setItem('isin2002_id', JSON.stringify(id));
    var color_isin_2002 = isin_2002_color.split(" ");
   // window.open("portfolio_isin.html",'_self',false);
    try{
        db = window.sqlitePlugin.openDatabase({name: "NSDL_ISIN.db", location: 2});
        db.transaction(selectFromDB,errorCB,successCBDate);
    }
    catch(err){
        return false;
    }
    $("#backg").css("display", "block");
    setTimeout(function(){
               var user_id = JSON.parse(localStorage.getItem('temp_userId1'));
               var dp_id = JSON.parse(localStorage.getItem('temp_dpid1'));
               var client_id = JSON.parse(localStorage.getItem('temp_clientId1'));
               var password = JSON.parse(localStorage.getItem('temp_password'));
               var id = JSON.parse(localStorage.getItem('isin2002_id'));
               var cuttOffDt = JSON.parse(localStorage.getItem('null_e'));
               setTimeout(function(){
               var portfolio_isin_url = base_url+'&userId='+user_id+'&functionId=2002&isin='+id+'&dpId='+dp_id+'&clientId='+client_id+'&passWord='+encodeURIComponent(password)+'&cuttoffDate='+cuttOffDt+'';
               var data = global_ajax(portfolio_isin_url);
               console.log(data);
               var result = $.parseJSON(data);
               var portfolioISINdata = data;
               localStorage.setItem('portfolioISINdata', JSON.stringify(portfolioISINdata));
               if(result.status == "S")
               {
               console.log("success...");
               db = window.sqlitePlugin.openDatabase({name: "NSDL_ISIN.db"});
               db.transaction(populateDB,errorCB,successCB);
               setTimeout(function(){
               window.open("portfolio_isin.html",'_self',false);
                          },1000);
               }
               else{
               $("#backg").css("display", "none");
               db = window.sqlitePlugin.openDatabase({name: "NSDL_ISIN.db", location: 2});
               db.transaction(listDB,errorCB,success_listCB1);
               swal({
                               title: " ",
                               text: result.errorDescription
                               },
                               function(){
                    
                    setTimeout(function(){
                               window.open("portfolio_isin.html",'_self',false);
                               },1000);
                    
                               });
               
               }
                },300);
               //}
               
               },200);
    
    
}


function portfolio_isin_details(){
    
    //var portfolio_2002 = JSON.parse(localStorage.getItem('portfolioISINdata'));
    //var result = $.parseJSON(portfolio_2002);console.log(result);
    
    //if(result.status == "S")
   // {
        var arrow_path_white;
        var isin_id = JSON.parse(localStorage.getItem('isin_id'));
        var table_isin = JSON.parse(localStorage.getItem('table_isin'));
        var single_isin_bg = JSON.parse(localStorage.getItem('single_isin_color'));
        if(single_isin_bg == "#139e15"){
            arrow_path_white = "img/up_white.png";
        }
        else{
            
            arrow_path_white = "img/down_white.png";
            
        }
        var tableValue8 = table_isin[8].split("(");
        var tableDays = tableValue8[1].split(")");
        var isin_date = JSON.parse(localStorage.getItem('currentServerTimeStamp'));
        $("#portfolio_isin_header").html("");
        $("#portfolio_isin_header").html('<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" style="border-collapse: collapse;background-color:'+single_isin_bg+';color:#fff;height:150px;"><tr><td align="left" valign="left" style="color:#fff;padding-top:5px;padding-left:5px;font-family:DroidSans-Bold;" colspan="3"><p class="p_4">'+table_isin[0]+'</p></td><tr><td style="padding-left:5px;"><p class="p_4">'+table_isin[1]+'</p></td><td>&nbsp;&nbsp;</td><td align="right" valign="middle" style="padding-top:5px;padding-right:5px;color:#fff;"><p class="p_4">CHANGE</p></td></tr><tr><td align="center" valign="middle" colspan="2"><img src='+arrow_path_white+' class="arrow" style="margin-left:25%;"/></td><td width="10%" align="right" valign="right" style="color:#fff;padding-right:5px;"><p class="p_4">&#8377;'+Math.abs(tableValue8[0])+'</p></td></tr><tr><td style="padding-left:5px;font-family:DroidSans-Bold;"><p class="p_4">&#8377;'+table_isin[4]+'</p></td><td><p class="p_4">&nbsp;</p></td><td width="10%" align="right" valign="right" style="color:#fff;padding-right:5px;"><p class="p_4">'+tableDays[0]+'</p></td></tr><tr><td style="color:#000;padding-left:5px;"><p class="p_4">STATEMENT OF HOLDING</p><p style="color:#000;font-weight: normal;font-style: normal;font-family: DroidSans;" class="p_4">as on '+isin_date+'</p></td><td><p class="p_4">&nbsp;</p></td><td align="right" valign="middle" class="refresh_icon" onclick="line_chart_refresh();" style="padding-right:5px;"></td></tr></table>');
    
    var last_month;
    //chart_data.length = 0;x_axis.length = 0;chart_dataNew.length = 0;
    console.log("successCB isin");
    var x_axis = JSON.parse(localStorage.getItem('x_axisArray'));
    var chart_data = JSON.parse(localStorage.getItem('chartArray'));
    var chart_dataNew = JSON.parse(localStorage.getItem('chartArray'));
    var ListData = [];ListData.length = 0;
    
    if(x_axis == null || x_axis.length == 0 || x_axis == "undefined"){
        var getlastm = getLastMonths(30);
        var temp_getlastm = (getlastm.toString()).split(" ");
        var getlast12m = getLastMonths(12*30);
        var temp_getlast12m = (getlast12m.toString()).split(" ");
        for(var i = 0;i<12;i++){
          ListData.push(0);
        }
        
        $("#isin_d1").html(temp_getlast12m[1]+" "+temp_getlast12m[3]);$("#isin_d2").html(temp_getlastm[1]+" "+temp_getlastm[3]);
        var ISinListNotExist = {
            labels : ["","","","","","","","","","","",""],
            datasets : [
                        {
                        label: "",
                        fillColor : "#193a47",
                        strokeColor : "#32b3e5",
                        pointColor : "#32b3e5",
                        pointStrokeColor : "#32b3e5",
                        pointHighlightFill : "#32b3e5",
                        pointHighlightStroke : "#32b3e5",
                        data : ListData
                        //data :[12000, 24000, 24200, 22700, 6400, 20300]
                        
                        }
                        
                        ]
            
        }
        $('#canvas2').remove(); // this is my <canvas> element
        $('#graph-container').append('<canvas id="canvas2"><canvas>');
        var canvas = document.getElementById('canvas2');
        var ctx = canvas.getContext('2d');
        // ctx.clearRect(0, 0, canvas.width, canvas.height);
        window.myLine = new Chart(ctx).Line(ISinListNotExist, {
                                            responsive: true
                                            });
        return false;
    }
    
   // else{
    
        var first = x_axis[0];
        var last = x_axis[x_axis.length - 1];
        for(var i = 0;i<12;i++){
            if(! (chart_data.length === 12)){
                chart_data.push(0);
            }
            else{
                console.log("array having 12 elements.");
                
            }
        }
        
        
        if(getLine_id == "line_gy")
        {
            var date1_s = first.split("-");
            var date2_s = last.split("-");
            var start_mon = monthNames[date1_s[1]-1];
            var end_mon = monthNames[date2_s[1]-1];
            var label_dt1 = start_mon+" "+date1_s[0];
            var label_dt2 = end_mon+" "+date2_s[0];
            $("#isin_d1").html(label_dt1);$("#isin_d2").html(label_dt2);
            var lineChartData = {
                labels : ["","","","","","","","","","","",""],
                datasets : [
                            {
                            label: "",
                            fillColor : "#193a47",
                            strokeColor : "#32b3e5",
                            pointColor : "#32b3e5",
                            pointStrokeColor : "#32b3e5",
                            pointHighlightFill : "#32b3e5",
                            pointHighlightStroke : "#32b3e5",
                            data : chart_data
                            //data :[12000, 24000, 24200, 22700, 6400, 20300, 7300,6800, 6800, 10500, 18000, 24000]
                            
                            }
                            
                            ]
                
            }
            $('#canvas2').remove(); // this is my <canvas> element
            $('#graph-container').append('<canvas id="canvas2"><canvas>');
            var canvas = document.getElementById('canvas2');
            var ctx = canvas.getContext('2d');
            //ctx.clearRect(0, 0, canvas.width, canvas.height);
            window.myLine = new Chart(ctx).Line(lineChartData, {
                                                responsive: true
                                                });
            
            var table_isin =JSON.parse(localStorage.getItem('table_isin'));console.log(table_isin);
            var month1 = chart_dataNew[chart_dataNew.length - 2];
            var month3 = chart_dataNew[chart_dataNew.length - 4];
            var month6 = chart_dataNew[chart_dataNew.length - 7];
            var yearOne = chart_dataNew[chart_dataNew.length - 1];
            var last_month1_per = infinite_val(FixedNum(((table_isin[4] - month1)/month1)*100));
            var last_month3_per = infinite_val(FixedNum(((table_isin[4] - month3)/month3)*100));
            var last_month6_per = infinite_val(FixedNum(((table_isin[4] - month6)/month6)*100));
            var lastYearOneper = infinite_val(FixedNum(((table_isin[4] - yearOne)/yearOne)*100));
            var color1 = change_color(last_month1_per);
            var color3 = change_color(last_month3_per);
            var color6 = change_color(last_month6_per);
            var colorYear = change_color(lastYearOneper);
            $("#month_line1").html('<p style="color:'+color1+';">'+last_month1_per+'%</p>');
            $("#month_line3").html('<p style="color:'+color3+';">'+last_month3_per+'%</p>');
            $("#month_line6").html('<p style="color:'+color6+';">'+last_month6_per+'%</p>');
            $("#YearOne").html('<p style="color:'+colorYear+';">'+lastYearOneper+'%</p>');
            //db.close(successCB, errorCB);
        }
        
        else{
            $("#line_gy").css("background-color","#545454");
            $("#line_gm").css("background-color","#cfa62a");
            var line_chartarray = JSON.parse(localStorage.getItem('chartArray'));//.slice(6,12);alert(line_chart6);
            var line_chart6 = line_chartarray.slice(line_chartarray.length-6,line_chartarray.length);
            var x_axisarray = JSON.parse(localStorage.getItem('x_axisArray'));
            var first = x_axisarray[x_axisarray.length - 6];
            var last = x_axisarray[x_axisarray.length - 1];
            var date1_s = first.split("-");
            var date2_s = last.split("-");
            var start_mon = monthNames[date1_s[1]-1];
            var end_mon = monthNames[date2_s[1]-1];
            var label_dt1 = start_mon+" "+date1_s[0];
            var label_dt2 = end_mon+" "+date2_s[0];
            $("#isin_d1").html(label_dt1);$("#isin_d2").html(label_dt2);
            for(var i = 0;i<6;i++){
                if(! (line_chart6.length === 6)){
                    line_chart6.push(0);
                }
                else{
                    console.log("array having 12 elements.");
                    
                }
            }
            var lineChartDatamonth6 = {
                labels : ["","","","","",""],
                datasets : [
                            {
                            label: "",
                            fillColor : "#193a47",
                            strokeColor : "#32b3e5",
                            pointColor : "#32b3e5",
                            pointStrokeColor : "#32b3e5",
                            pointHighlightFill : "#32b3e5",
                            pointHighlightStroke : "#32b3e5",
                            data : line_chart6
                            //data :[12000, 24000, 24200, 22700, 6400, 20300]
                            
                            }
                            
                            ]
                
            }
            $('#canvas2').remove(); // this is my <canvas> element
            $('#graph-container').append('<canvas id="canvas2"><canvas>');
            var canvas = document.getElementById('canvas2');
            var ctx = canvas.getContext('2d');
            // ctx.clearRect(0, 0, canvas.width, canvas.height);
            window.myLine = new Chart(ctx).Line(lineChartDatamonth6, {
                                                responsive: true
                                                });
        }
   // }
    
    
    
}
function createDB(tx) {
    tx.executeSql('CREATE TABLE IF NOT EXISTS Max_ISIN (id INTEGER PRIMARY KEY AUTOINCREMENT,ISIN TEXT, PRICE NUMERIC, SQ_NO INTEGER, DATE TEXT)');
    
}
function populateDB(tx) {
    var portfolio_2002 = JSON.parse(localStorage.getItem('portfolioISINdata'));
    var result = $.parseJSON(portfolio_2002);console.log(result);
    var get_data = result.isinWiseList;
     //tx.executeSql('DROP TABLE IF EXISTS Max_ISIN');
    tx.executeSql('CREATE TABLE IF NOT EXISTS Max_ISIN (id INTEGER PRIMARY KEY AUTOINCREMENT,ISIN TEXT, PRICE NUMERIC, SQ_NO INTEGER, DATE TEXT)');
    for(var i=0;i < get_data.length;i++){
        tx.executeSql('INSERT INTO Max_ISIN (ISIN , PRICE, SQ_NO, DATE) VALUES (?,?, ?,?)', [result.isin , get_data[i].closingPrice , get_data[i].sequenceNo , get_data[i].date]);
    }
    
    getvalue();
    
}
function getvalue(){
    // db.close(successCB, errorCB);
    db = window.sqlitePlugin.openDatabase({name: "NSDL_ISIN.db", location: 2});
    db.transaction(listDB,errorCB,success_listCB1);
}
function errorCB(tx, err) {
    console.log("Error processing SQL: "+err);
    $("#backg").css("display", "none");
    closedb_call();
    return false;
}

function closedb_call() {
    $("#backg").css("display", "none");
    console.log("close db!");
    db.close(successCB, errorCB);
    
}
function successCB() {
    console.log("successCB!");
    //db.close(successCB, errorCB);
    
}


function listDB(tx) {
    //Select ISIN , Max(PRICE) as price,strftime("%Y-%m",[date]) as date from isin_table where isin_no="INE865C01022" group by strftime("%Y-%m",[date]), isin_no Order By strftime("%Y-%m",[date]) ASC
    var push_maxPrice = [];
    var d = new Date();  //timestamp
    
    var da = d.getDate();//day
    
    var mon = d.getMonth()+1;   //month
    
    var yr = d.getFullYear();   //year
    
    if (da < 10)
        
        da = "0" + da;
    
    else{da = da;}
    if (mon < 10)
        
        mon = "0" + mon;
    
    else{mon = mon;}
    var current_timming =yr+"-"+mon+"-"+da;
    var isin = JSON.parse(localStorage.getItem('isin2002_id'));
    tx.executeSql('Select ISIN , Max(PRICE) as price,strftime("%Y-%m",[DATE]) as date from Max_ISIN where ISIN = "'+isin+'" and DATE >date("'+current_timming+'","-12 month") group by strftime("%Y-%m",[DATE]) order by strftime("%Y-%m",[DATE]) ASC, ISIN', [], function(tx,results){
                  len = results.rows.length;
                  push_maxPrice.length = 0;
                  for (var i = 0; i < results.rows.length; i++) {
                  var row = results.rows.item(i);
                  var date_isin = row.date;
                  var price = row.price;
                  push_maxPrice.push({
                                     date_d : date_isin,
                                     price_isin : price
                                     
                                     });
                  }
                  localStorage.setItem('pushmaxPrice', JSON.stringify(push_maxPrice));
                  });
    
    
    //db.close(successCB, errorCB);
}

function success_listCB1() {
    
    
    var chart_data = [];var x_axis = [];var chart_dataNew = [];
    chart_data.length = 0;x_axis.length = 0;chart_dataNew.length = 0;
    console.log("successCB!!!!!!!");
    $("#backg").css("display", "none");
    $.each(JSON.parse(localStorage.getItem('pushmaxPrice')), function (index, value) {
           x_axis.push( value.date_d );
           chart_data.push( value.price_isin );
           });
    
    var d = new Date();  //timestamp
    
    var mon = d.getMonth()+1;   //month
    
    var yr = d.getFullYear();   //year
    if (mon < 10)
        
        mon = "0" + mon;
    
    else{mon = mon;}
    var current_month = yr +"-"+mon;
    if(x_axis[x_axis.length - 1] == current_month){
        x_axis.pop();
        chart_data.pop();
        
    }
    else{
        concole.log("array do not have current date.");
    }
    chart_dataNew = chart_data;
    localStorage.setItem('chartArray', JSON.stringify(chart_data));
     localStorage.setItem('x_axisArray', JSON.stringify(x_axis));
     //localStorage.setItem('chart_dataNew', JSON.stringify(chart_dataNew));console.log();
    
}


function paid_soh(){
                     $('.slide-in').toggleClass('on');
                      $('#main_wrapper').toggleClass('on');
                      outIn = 'in';
                     $("#backg").css("display", "block");
                     setTimeout(function(){
                                var user_id = JSON.parse(localStorage.getItem('temp_userId1'));
                                var dp_id = JSON.parse(localStorage.getItem('temp_dpid1'));
                                var client_id = JSON.parse(localStorage.getItem('temp_clientId1'));
                                var portfolio_url = base_url+'&userId='+user_id+'&functionId=2001&dpId='+dp_id+'&clientId='+client_id+'';
                                var data = global_ajax(portfolio_url);
                                console.log(data);
                                var result = $.parseJSON(data);
                                console.log(data);
                                var portfolio_data = data;
                                localStorage.setItem('portfolio_data', JSON.stringify(portfolio_data));
                                if(result.status == "S")
                                {
                                var portfolio_2003 = base_url+'&userId='+user_id+'&functionId=2003&&dpId='+dp_id+'&clientId='+client_id+'';
                                var data = global_ajax(portfolio_2003);
                                console.log(data);
                                var paid_2003 = data;
                                localStorage.setItem('paid_2003', JSON.stringify(paid_2003));
                                var result = $.parseJSON(data);
                                window.open("portfolio.html",'_self',false);
                                }
                                else{
                                window.open("portfolio.html",'_self',false);
                                }
                                
                                },100);
                     
                     }

function paidSOH(){
    //$(".SlideMenu").hide();
    $(".overlay_user").hide();
    var EXPDate = JSON.parse(localStorage.getItem('expiredPortfolio'));
    if(EXPDate == "ExP")
    {
        swal({
             title: " ",
             text: "Paid SOH is expired."
             },
             function(){
             $(".paid_soh").off("click");
             $("#backg").css("display", "none");
             return false;
             });
        
        
    }
    else
    {
       window.open("portfolio.html",'_self',false);
    }
}
//line graph for 6 month and 1 year

$(document).ready(function () {
                  
                  // .click(function(){
                  //.on("click touchstart",function() {
                 
                  $("#line_gm").click(function(){
                                     //alert(chart_data.slice(0, 6));
                                      
                                      var last_month;
                                      getLine_id = "line_gm";
                                     $("#line_gy").css("background-color","#545454");
                                     $("#line_gm").css("background-color","#cfa62a");
                                      var x_axisarray = JSON.parse(localStorage.getItem('x_axisArray'));
                                      var line_chartarray = JSON.parse(localStorage.getItem('chartArray'));
                                      if(x_axisarray == null || x_axisarray.length == 0){
                                      console.log("NO DATA");
                                      return false;
                                      }
                                      else{
                                      var line_chart6 = line_chartarray.slice(line_chartarray.length-6,line_chartarray.length);
                                      var first = x_axisarray[x_axisarray.length - 6];
                                      var last = x_axisarray[x_axisarray.length - 1];
                                      for(var i = 0;i<6;i++){
                                      if(! (line_chart6.length === 6)){
                                      line_chart6.push(0);
                                      }
                                      else{
                                      console.log("array having 12 elements.");
                                      
                                      }
                                      }
                                      //var line_chartarray = JSON.parse(localStorage.getItem('chartArray'));//.slice(6,12);alert(line_chart6);
                                      //var line_chart6 = line_chartarray.slice(line_chartarray.length-6,line_chartarray.length);
                                      //var x_axisarray = JSON.parse(localStorage.getItem('x_axisArray'));
                                      var date1_s = first.split("-");
                                      var date2_s = last.split("-");
                                      var start_mon = monthNames[date1_s[1]-1];
                                      var end_mon = monthNames[date2_s[1]-1];
                                      var label_dt1 = start_mon+" "+date1_s[0];
                                      var label_dt2 = end_mon+" "+date2_s[0];
                                      $("#isin_d1").html(label_dt1);$("#isin_d2").html(label_dt2);
                                      var lineChartDatamonth6 = {
                                      labels : ["","","","","",""],
                                      datasets : [
                                                  {
                                                  label: "",
                                                  fillColor : "#193a47",
                                                  strokeColor : "#32b3e5",
                                                  pointColor : "#32b3e5",
                                                  pointStrokeColor : "#32b3e5",
                                                  pointHighlightFill : "#32b3e5",
                                                  pointHighlightStroke : "#32b3e5",
                                                  data : line_chart6
                                                  //data :[12000, 24000, 24200, 22700, 6400, 20300]
                                                  
                                                  }
                                                  
                                                  ]
                                      
                                      }
                                      $('#canvas2').remove(); // this is my <canvas> element
                                      $('#graph-container').append('<canvas id="canvas2"><canvas>');
                                      var canvas = document.getElementById('canvas2');
                                      var ctx = canvas.getContext('2d');
                                      // ctx.clearRect(0, 0, canvas.width, canvas.height);
                                      window.myLine = new Chart(ctx).Line(lineChartDatamonth6, {
                                                                          responsive: true
                                                                          });
                                      }
                                      
                                     });
                  
                  $("#line_gy").click(function(){
                                      getLine_id = "line_gy";
                                    $("#line_gm").css("background-color","#545454");
                                    $("#line_gy").css("background-color","#cfa62a");
                                      var x_axisarray = JSON.parse(localStorage.getItem('x_axisArray'));
                                      var line_chartarray = JSON.parse(localStorage.getItem('chartArray'));
                                      if(x_axisarray == null || x_axisarray.length == 0){
                                      console.log("NO DATA");
                                      return false;
                                      }
                                      else{
                                      var first = x_axisarray[0];
                                      var last = x_axisarray[x_axisarray.length - 1];
                                      
                                      for(var i = 0;i<12;i++){
                                      if(! (line_chartarray.length === 12)){
                                      line_chartarray.push(0);
                                      }
                                      else{
                                      console.log("array having 12 elements.");
                                      
                                      }
                                      }
                                      
                                      var date1_s = first.split("-");
                                      var date2_s = last.split("-");
                                      var start_mon = monthNames[date1_s[1]-1];
                                      var end_mon = monthNames[date2_s[1]-1];
                                      var label_dt1 = start_mon+" "+date1_s[0];
                                      var label_dt2 = end_mon+" "+date2_s[0];
                                      $("#isin_d1").html(label_dt1);$("#isin_d2").html(label_dt2);
                                      var lineChartyear1 = {
                                      labels : ["","","","","","","","","","","",""],
                                      datasets : [
                                                  {
                                                  label: "",
                                                  fillColor : "#193a47",
                                                  strokeColor : "#32b3e5",
                                                  pointColor : "#32b3e5",
                                                  pointStrokeColor : "#32b3e5",
                                                  pointHighlightFill : "#32b3e5",
                                                  pointHighlightStroke : "#32b3e5",
                                                  data : line_chartarray
                                                  // data :[12000, 24000, 24200, 22700, 6400, 20300, 7300,6800, 6800, 10500, 18000, 24000]
                                                  
                                                  }
                                                  
                                                  ]
                                      
                                      }
                                      $('#canvas2').remove(); // this is my <canvas> element
                                      $('#graph-container').append('<canvas id="canvas2"><canvas>');
                                      var canvas = document.getElementById('canvas2');
                                      var ctx = canvas.getContext('2d');
                                      //ctx.clearRect(0, 0, canvas.width, canvas.height);
                                      window.myLine = new Chart(ctx).Line(lineChartyear1, {
                                                                          responsive: true
                                                                          });
                                      }
                                      });
                  
                                      
                  });


function line_chart_refresh(){
    var user_id = JSON.parse(localStorage.getItem('temp_userId1'));
    var dp_id = JSON.parse(localStorage.getItem('temp_dpid1'));
    var client_id = JSON.parse(localStorage.getItem('temp_clientId1'));
    var password = JSON.parse(localStorage.getItem('temp_password'));
    var id = JSON.parse(localStorage.getItem('isin2002_id'));
    db = window.sqlitePlugin.openDatabase({name: "NSDL_ISIN.db", location: 2});
    db.transaction(selectFromDB,errorCB,successCBDate);
    var cuttOffDt = JSON.parse(localStorage.getItem('null_e'));
    //var cuttOffDt = "null";
    var portfolio_isin_url = base_url+'&userId='+user_id+'&functionId=2002&isin='+id+'&dpId='+dp_id+'&clientId='+client_id+'&passWord='+encodeURIComponent(password)+'&cuttoffDate='+cuttOffDt+'';
    var portfolio_url = base_url+'&userId='+user_id+'&functionId=2001&dpId='+dp_id+'&clientId='+client_id+'';
    $("#backg").css("display", "block");
    setTimeout(function(){
               var data = global_ajax(portfolio_url);
               console.log(data);
               var result = $.parseJSON(data);
               var portfolio_data = data;
               localStorage.setItem('portfolio_data', JSON.stringify(portfolio_data));
               
               var NSETimeOfLastFileCreation = result.NSETimeOfLastFileCreation;
               var split_date = NSETimeOfLastFileCreation.split("-");
               var split_hr = split_date[2].split(" ");
               var mon = monthNames[split_date[1]-1];
               var split_hr_min = split_hr[1].split(":");
               var currentServerTimeStamp = split_hr[0] + " " + mon + "," + split_date[0] + " | "+split_hr_min[0]+":"+split_hr_min[1];
               
               var arrow_path_white;
               var isin_id = JSON.parse(localStorage.getItem('isin_id'));
               var table_isin = JSON.parse(localStorage.getItem('table_isin'));
               var single_isin_bg = JSON.parse(localStorage.getItem('single_isin_color'));
               if(single_isin_bg == "#139e15"){
               arrow_path_white = "img/up_white.png";
               }
               else{
               
               arrow_path_white = "img/down_white.png";
               
               }
               var tableValue8 = table_isin[8].split("(");
               var tableDays = tableValue8[1].split(")");
               var isin_date = currentServerTimeStamp;
               $("#portfolio_isin_header").html("");
               $("#portfolio_isin_header").html('<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" style="border-collapse: collapse;background-color:'+single_isin_bg+';color:#fff;height:150px;"><tr><td align="left" valign="left" style="color:#fff;padding-top:5px;padding-left:5px;" colspan="3"><p class="p_4">'+table_isin[0]+'</p></td><tr><td style="padding-left:5px;"><p class="p_4">'+table_isin[1]+'</p></td><td>&nbsp;&nbsp;</td><td align="right" valign="middle" style="padding-top:5px;padding-right:5px;color:#fff;"><p class="p_4">CHANGE</p></td></tr><tr><td align="center" valign="middle" colspan="2"><img src='+arrow_path_white+' class="arrow" style="margin-left:25%;"/></td><td width="10%" align="right" valign="right" style="color:#fff;padding-right:5px;"><p class="p_4">&#8377;'+Math.abs(tableValue8[0])+'</p></td></tr><tr><td style="padding-left:5px;"><p class="p_4">&#8377;'+table_isin[4]+'</p></td><td><p class="p_4">&nbsp;</p></td><td width="10%" align="right" valign="right" style="color:#fff;padding-right:5px;"><p class="p_4">'+tableDays[0]+'</p></td></tr><tr><td style="color:#000;padding-left:5px;"><p class="p_4">STATEMENT OF HOLDING</p><p style="color:#000;font-weight: normal;font-style: normal;font-family: DroidSans;" class="p_4">as on '+isin_date+'</p></td><td><p class="p_4">&nbsp;</p></td><td align="right" valign="middle" class="refresh_icon" onclick="line_chart_refresh();" style="padding-right:5px;"></td></tr></table>');
               if(result.status == "S")
               {
               // LastFileCreation date
               $.ajax({
                      type: "GET",
                      url: portfolio_isin_url,
                      dataType:"html",
                      //contentType: "application/json",
                      cache:false,
                      crossDomain: true,
                      async: false,
                      success: function (data) {
                      console.log(data);
                      var result = $.parseJSON(data);
                      if(result.status == "S"){
                      console.log(data);
                      var portfolio_isin_refresh = data;
                      localStorage.setItem('portfolioISINdata', JSON.stringify(portfolio_isin_refresh));
                      db = window.sqlitePlugin.openDatabase({name: "NSDL_ISIN.db", location: 2});
                      db.transaction(populateDB,errorCB,successCB);
                      setTimeout(function(){
                                 portfolio_isin_details();
                                 },1000);
                      
                      }
                      else{
                      $("#backg").css("display", "none");
                      db = window.sqlitePlugin.openDatabase({name: "NSDL_ISIN.db", location: 2});
                      db.transaction(listDB,errorCB,success_listCB1);
                      swal({
                           title: " ",
                           text: result.errorDescription
                           },
                           function(){
                           setTimeout(function(){
                                      portfolio_isin_details();
                                      },1000);
                           });
                      
                      }
                      
                      },
                      error: function (xhr, status, error) {
                      $("#backg").css("display", "none");
                      swal({
                           title: " ",
                           text: "The request timed out."
                           },
                           function(){
                           
                           db = window.sqlitePlugin.openDatabase({name: "NSDL_ISIN.db", location: 2});
                           db.transaction(listDB,errorCB,success_listCB1);
                           setTimeout(function(){
                                      portfolio_isin_details();
                                      },1000);
                           });
                      
                      }
                      
                      });
               }
               else{
               $("#backg").css("display", "block");
               setTimeout(function(){
                          $.ajax({
                                 type: "GET",
                                 url: portfolio_isin_url,
                                 dataType:"html",
                                 //contentType: "application/json",
                                 cache:false,
                                 crossDomain: true,
                                 async: false,
                                 success: function (data) {
                                 console.log(data);
                                 var result = $.parseJSON(data);
                                 if(result.status == "S"){
                                 console.log(data);
                                 var portfolio_isin_refresh = data;
                                 localStorage.setItem('portfolioISINdata', JSON.stringify(portfolio_isin_refresh));
                                 db = window.sqlitePlugin.openDatabase({name: "NSDL_ISIN.db", location: 2});
                                 db.transaction(populateDB,errorCB,successCB);
                                 setTimeout(function(){
                                            portfolio_isin_details();
                                            },1000);
                                 
                                 }
                                 else{
                                 $("#backg").css("display", "none");
                                 db = window.sqlitePlugin.openDatabase({name: "NSDL_ISIN.db", location: 2});
                                 db.transaction(listDB,errorCB,success_listCB1);
                                 swal({
                                      title: " ",
                                      text: result.errorDescription
                                      },
                                      function(){
                                      
                                      setTimeout(function(){
                                                 portfolio_isin_details();
                                                 },1000);
                                      });
                                 
                                 }
                                 
                                 },
                                 error: function (xhr, status, error) {
                                 $("#backg").css("display", "none");
                                 swal({
                                      title: " ",
                                      text: "The request timed out."
                                      },
                                      function(){
                                      
                                      db = window.sqlitePlugin.openDatabase({name: "NSDL_ISIN.db", location: 2});
                                      db.transaction(listDB,errorCB,success_listCB1);
                                      setTimeout(function(){
                                                 portfolio_isin_details();
                                                 },1000);
                                      });
                                 
                                 }
                                 
                                 });
                          $("#backg").css("display", "none");
                          },200);
               }
               $("#backg").css("display", "none");
               },200);
    
    
}


function selectFromDB(tx) {
    var isin = JSON.parse(localStorage.getItem('isin2002_id'));
    // Select ISIN ,Max(strftime("%Y-%m-%d",[DATE])) as date from Max_ISIN where ISIN = "isin1"
    tx.executeSql('SELECT ISIN ,Max(strftime("%Y-%m-%d",[DATE])) as date FROM Max_ISIN where ISIN = "'+isin+'" ', [], function(tx,results){
                  len = results.rows.length;
                  for (var i = 0; i < results.rows.length; i++) {
                  var row = results.rows.item(i);
                  var LastTransactiondt = row.date;
                  localStorage.setItem('null_e', JSON.stringify(LastTransactiondt));
                  }
                  });
    
    //db.close(successCB, errorCB);
}

function successCBDate(){
    console.log("successCBDate");
   
}

