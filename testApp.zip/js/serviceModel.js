

//Global variable declaration
var isin_time = [];var id_array = [];var ids_edis = [];var global_ajax;var box1;var portfolio_sec_type = [];var portfolio_grp_hold = [];var security_order;var inputs;var number_format;var change_color;
//json array for security order..


//global ajax call
number_format = function(obj_temp)
{
    var number_f,value;var number_format_value1;
    if(isNaN(obj_temp)){
        number_f = "Not Available";
        
    }
    else{
        var value1 = obj_temp;
        var str = value1.toString();
        var results = "";
        if(/[.]/g.test(str)){
            var storeit = str.split('.');
            value=storeit[0].replace(",","");
            var len = value.length-1;
            var nDigits = 0;
            
            var lastDigit=value.charAt(value.length-1);
            
            for (var i = len - 1; i >= 0; i--)
            {
                results = value.charAt(i) + results;
                nDigits++;
                if (((nDigits % 2) == 0) && (i > 0))
                {
                    results = "," + results;
                }
                
            }
            if(storeit[1].length == 1){
                number_format_value1 = "&#8377;"+results+lastDigit+'.'+storeit[1]+0;
            }
            else{
                number_format_value1 = "&#8377;"+results+lastDigit+'.'+storeit[1];
            }
            
            number_f = number_format_value1;
          
        }
        else{
            value=str.replace(",","");
            var len = value.length-1;
            var nDigits = 0;
            
            var lastDigit=value.charAt(value.length-1);
            
            for (var i = len - 1; i >= 0; i--)
            {
                results = value.charAt(i) + results;
                nDigits++;
                if (((nDigits % 2) == 0) && (i > 0))
                {
                    results = "," + results;
                }
                
            }
            var number_format_value = "&#8377;"+results+lastDigit+'.00';
            number_f = number_format_value;
        }
        
        
    }
    
    return (number_f);
}

number_format_s = function(obj_temp)
{
    var number_s,value;
    if(isNaN(obj_temp) || !isFinite(obj_temp)){
        number_s = "0.00";
        
    }
    else{
        var value1 = obj_temp;
        var str = value1.toString();
        var results = "";
        if(/[.]/g.test(str)){
            var storeit = str.split('.');
            value=storeit[0].replace(",","");
            var len = value.length-1;
            var nDigits = 0;
            
            var lastDigit=value.charAt(value.length-1);
            
            for (var i = len - 1; i >= 0; i--)
            {
                results = value.charAt(i) + results;
                nDigits++;
                if (((nDigits % 2) == 0) && (i > 0))
                {
                    results = "," + results;
                }
                
            }
            var number_format_value1 = results+lastDigit+'.'+storeit[1];
            number_s = number_format_value1.replace("-,","-");
        }
        else{
            value=str.replace(",","");
            var len = value.length-1;
            var nDigits = 0;
            
            var lastDigit=value.charAt(value.length-1);
            
            for (var i = len - 1; i >= 0; i--)
            {
                results = value.charAt(i) + results;
                nDigits++;
                if (((nDigits % 2) == 0) && (i > 0))
                {
                    results = "," + results;
                }
                
            }
            var number_format_value = results+lastDigit+'.00';
            number_s = number_format_value.replace("-,","-");
            
            
        }
        
        
    }
    
    return (number_s);
}
var change_class;
change_color = function(obj_color){
    if(obj_color >= 0){
        change_class = "#139e15";
        
    }
    else{
        
        change_class = "#e60b0b";
        
    }
    return (change_class);
}

change_image = function(obj_img){
    var image_uri;
    if(obj_img >= 0){
        image_uri = "img/green.png";
        
    }
    else{
        
        image_uri = "img/red.png";
        
    }
    return (image_uri);
}
white_image = function(obj_white){
    var white_uri;
    if(obj_white >= 0){
        white_uri = "img/up_white.png";
    }
    else{
        
        white_uri = "img/down_white.png";
        
    }
    return (white_uri);
}

//fix number without rounding to 2 decimal places
function FixedNum(num){
    var fixed_val;
    if(isNaN(num) || !isFinite(num)){
        fixed_val = "0.00";
        
    }
    else{
        if(num >= 0){
            fixed_val = (Math.floor(100 * num) / 100).toFixed(2);
        }
        else{
            
            fixed_val = (Math.ceil(100 * num) / 100).toFixed(2);
            
        }
    }
    
    return (fixed_val);
}
function infinite_val(val){
    var infinite_val;
    if(isNaN(val) || !isFinite(val)){
        infinite_val = "0.00";
        
    }
    else{
        if(val >= 0){
            infinite_val = "+" + val;
        }
        else{
            infinite_val = val;
        }
        
    }
    return (infinite_val);
}
//subtract date with days
function DateSub(dateMs, days){
    var newDate;
    var msToSub = days * 24 * 60 * 60 * 1000;
    var newDate = new Date(dateMs - msToSub);
    return (newDate);
}
getMonth = function (monthStr){
    return new Date(monthStr+'-1-01').getMonth();
}
getBetweenDate = function(startDt,endDt){
    console.log(startDt+"= startDt");console.log(endDt+"= endDt")
    var SmonNum = getMonth(startDt[1]);
    var start = new Date(startDt[3],SmonNum,startDt[2]),
    end = new Date(endDt[0],endDt[1] - 1,endDt[2]),
    currentDate = new Date(start),
    between = []
    ;
    console.log(start+"= start..");console.log(end+"= end..")
    while (currentDate <= end) {
        between.push(new Date(currentDate));
        currentDate.setDate(currentDate.getDate() + 1);
    }
    
    console.log(between);
    return(between);
    
}
//get last month from current month subtracting days
function getLastMonths(lstmon){
    var nd;
    var executionDate = new Date();
    var dd = executionDate.getDate();
    var mm = executionDate.getMonth(); //January is 0!
    var yyyy = executionDate.getFullYear();
    var date = new Date(yyyy, mm, dd);
    var newdate = new Date(date);
    newdate.setDate(newdate.getDate() - lstmon);
    nd = new Date(newdate);
    return(nd);
}

/*check networkconnection*/
function connection(){
    
    
    var networkState = navigator.connection.type;
    
    var states = {};
    states[Connection.UNKNOWN]  = 'Unknown connection';
    states[Connection.ETHERNET] = 'Ethernet connection';
    states[Connection.WIFI]     = 'WiFi connection';
    states[Connection.CELL_2G]  = 'Cell 2G connection';
    states[Connection.CELL_3G]  = 'Cell 3G connection';
    states[Connection.CELL_4G]  = 'Cell 4G connection';
    states[Connection.CELL]     = 'Cell generic connection';
    states[Connection.NONE]     = 'No network connection';
    
    console.log('Connection type: ' + networkState);
    if(networkState == "none"){
        swal({
             title: " ",
             text: "Internet connection not available"
             },
             function(){
             
             return false;
             });
        
    }
    else{
        console.log("internet connection available");
        //$("#backg").css("display", "block");
    }
    
    
}

global_ajax = function(obj_url)
{
    
    var result="";
    $.ajax({
           type: "GET",
           url: obj_url,
           dataType:"html",
           cache:false,
           timeout: 60000, //Set your timeout value in milliseconds or 0 for unlimited
           crossDomain: true,
           async: false,
           
           success: function (data) {
           result = data;
           //localStorage.setItem('temp_data', JSON.stringify(temp_data));
           var result1 = $.parseJSON(result);
           if(result1.errorCode == "9998"){
           $("#backg").css("display", "none");
           swal({
                title: " ",
                text: "Session Time Out,Please Login again.."
                },
                function(){
                window.open("index.html",'_self',false);
                });
           }
           
           },
           error: function (xhr, status, error) {
           if(status === "timeout") {
           $("#backg").css("display", "none");
           swal({
                title: " ",
                text: "The request timed out."
                },
                function(){
                return false;
                });
           } else {
           $("#backg").css("display", "none");
           if(error == ""){
           swal({
                title: " ",
                text: "The request timed out."
                },
                function(){
                if( document.getElementById("pass") ){
                document.getElementById("pass").value = "";
                return false;
                }
                return false;
                });
           }
           else{
           swal({
                title: " ",
                text: error
                },
                function(){
                if( document.getElementById("pass") ){
                document.getElementById("pass").value = "";
                return false;
                }
                return false;
                });
           }
           
           }//end of else
           
           }//end of error
           });
    return result;
    
}

//*********************SOH*****************************//
function FreeUserSoh(fusURL){
    var resultSOH = "";
    $.ajax({
           type: "GET",
           url: fusURL,
           dataType:"html",
           cache:false,
           crossDomain: true,
           async: false,
           success: function (data) {
           resultSOH = data;
           console.log(data);
           var result_soh = $.parseJSON(data);console.log(result_soh.status);
           var soh_data = data;
           localStorage.setItem('soh_data', JSON.stringify(soh_data));
           console.log(soh_data);
           //window.open("equity.html",'_self',false);
           },
           error: function (xhr, status, error) {
           $("#backg").css("display", "none");
           resultSOH = "RequestTimeOut";
           swal({
                title: " ",
                text: "The request timed out."
                },
                function(){
                return false;
                });
           
           }
           });
    
    return resultSOH;
    
}
//*************************************************//
expDateDbCall = function(){
    db_Exp = window.sqlitePlugin.openDatabase({name: "NSDL_ISIN.db", location: 2});
    db_Exp.transaction(expiryDateDB,errorCB,expiryDatesuccessCB);
}
function expiryDateDB(tx) {
    var setValueDay5;
    // tx.executeSql('DROP TABLE IF EXISTS Max_ISIN');
    tx.executeSql('CREATE TABLE IF NOT EXISTS ExpiryDate (id unique,markExpiry TEXT)');
    tx.executeSql('INSERT INTO ExpiryDate (id,markExpiry) VALUES (?,?)', [1,'day5']);
    tx.executeSql('INSERT INTO ExpiryDate (id,markExpiry) VALUES (?,?)', [2,'day15']);
    tx.executeSql('Select * from ExpiryDate', [], function(tx,results){
                  len = results.rows.length;
                  var row1 = results.rows.item(0);
                  var row2 = results.rows.item(1);
                  var paidExpiry = JSON.parse(localStorage.getItem('TpaidexpiryDt'));
                  var RealTmPaidexpiryDt = JSON.parse(localStorage.getItem('RealTmpaidexpiryDt'));
                  var temp_paidExpiry = paidExpiry.split("-");
                  var today, someday, text;
                  today = new Date();
                  var tempTodayDate = (today.toString()).split(" ");
                  var getTodayDt = tempTodayDate[1]+" "+tempTodayDate[2]+" "+tempTodayDate[3];
                  //someday = new Date();
                  someday = new Date(temp_paidExpiry[0], temp_paidExpiry[1] - 1, temp_paidExpiry[2]);
                  //subtract expiry date with days 1, 5, 15
                  var date1 = new Date(temp_paidExpiry[0], temp_paidExpiry[1] - 1, temp_paidExpiry[2]);
                  var dateMs = date1 - 0;
                  var days = 1;var days5 = 5;var days15 = 15;
                  var msToSubtract1 = DateSub(dateMs, days);console.log(msToSubtract1 +"day one");
                  var tempCompare1 = (msToSubtract1.toString()).split(" ");
                  var msToSubtract5 = DateSub(dateMs, days5);console.log(msToSubtract5 +"day 5");
                  var tempCompare5 = (msToSubtract5.toString()).split(" ");
                  var msToSubtract15 = DateSub(dateMs, days15);console.log(msToSubtract15 +"day 15");
                  var tempCompare15 = (msToSubtract15.toString()).split(" ");
                  var msToAdd = 1 * 24 * 60 * 60 * 1000;
                  var newAddedDate = new Date(dateMs + msToAdd);
                  var newAddedDateTest = (newAddedDate.toString()).split(" ");
                  //last date after expiry.
                  var storeLastDt = (newAddedDateTest[1]+" "+newAddedDateTest[2]+" "+newAddedDateTest[3]);
                  tempDatesArray5 = getBetweenDate(tempCompare5,temp_paidExpiry);console.log(tempDatesArray5);
                  tempDatesArray15 = getBetweenDate(tempCompare15,temp_paidExpiry);
                  tempDatesArray15.pop();
                  //var storePrevLastDt = tempDatesArray15[tempDatesArray15.length - 1];
                  var storePrevLastDtTest = ((tempDatesArray15[tempDatesArray15.length - 1]).toString()).split(" ");
                  //previous date from expiry.
                  var storePrevLastDt = (storePrevLastDtTest[1]+" "+storePrevLastDtTest[2]+" "+storePrevLastDtTest[3]);
                  tempDatesArray15.pop();
                  //last fifteen days expiry message.
                  for(var i=0;i<tempDatesArray15.length;i++){
                  var test2 = (tempDatesArray15[i].toString()).split(" ");
                  var tempTestDate2 = (test2[1]+" "+test2[2]+" "+test2[3]);
                  if(getTodayDt == tempTestDate2){
                  if(row2.markExpiry == 'day15'){
                  setValueDay15 = "true";
                  }//end of if
                  else{
                  console.log("expiry day 5.");
                  }
                  
                  }//end if
                  else{
                  console.log("today greater than expiry date.");
                  }
                  
                  }//end of for
                  //update mark 15
                  if(setValueDay15 == "true"){
                  // db_Exp.transaction(UpdateExpiryDateDB,errorCB,UpdateExpiryDatesuccessCB);
                  db_Exp.executeSql('UPDATE ExpiryDate SET markExpiry = "marked" Where markExpiry = "day15"', [], function (res) {
                                    swal("Paid SOH will expire on date "+RealTmPaidexpiryDt+"");
                                    }, function(error) {
                                    console.log("Error processing SQL: ");
                                    });
                  }
                  else{
                  console.log("day 15 true.");
                  }
                  if(getTodayDt == storePrevLastDt){
                  swal("Paid SOH will expire on date "+RealTmPaidexpiryDt+"");
                  }
                  else if(getTodayDt == storeLastDt){
                  swal("Paid SOH will expire on date "+RealTmPaidexpiryDt+"");
                  }
                  else{
                  console.log("expiry date reminder exceeded.");
                  }
                  });
    
}

function errorCB(tx, err) {
    console.log("Error processing SQL: "+err);
    // closedb_call();
    
}

// Transaction success callback
function expiryDatesuccessCB() {
    console.log("success!");
    
}

