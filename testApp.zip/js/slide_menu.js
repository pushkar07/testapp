

function date() {
    
    
    var currentTime = new Date ( );
    var currentHours = currentTime.getHours ( );
    var currentMinutes = currentTime.getMinutes ( );
    var currentSeconds = currentTime.getSeconds ( );
    
    
    // Pad the minutes and seconds with leading zeros, if required
    currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;
    currentSeconds = ( currentSeconds < 10 ? "0" : "" ) + currentSeconds;
    
    // Choose either "AM" or "PM" as appropriate
    var timeOfDay = ( currentHours < 12 ) ? "AM" : "PM";
    
    // Convert the hours component to 12-hour format if needed
    currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
    
    // Convert an hours component of "0" to "12"
    currentHours = ( currentHours == 0 ) ? 12 : currentHours;
    currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
    // Compose the string for display
    var currentTimeString = currentHours + ":" + currentMinutes + ":" + currentSeconds + " " + timeOfDay;
    var login_time = JSON.parse(localStorage.getItem('temp_current_dt'));
    $("#current_dt_u").html("<b>"+login_time+' '+currentTimeString+"</b>");
    
}

$(document).ready(function(e) {
                  $(".SlideMenu").append('<div class="slide-in"><div style="background-color:#000;"><ul class="tk-museo-sans"><li style="background-color:#787878;"><div class="intro"><div class="box_user"><table border="0" align="center" cellpadding="0" cellspacing="0" width="100%" style="border-collapse: collapse;color:#fff;margin:0.5em;"><tr><td colspan="3" id="user_welcome" class="content_wrap1" height="35"></tr><tr class="box_text content_wrap1"><td align="left" valign="top" width="48%" height="35">DP ID</td><td align="center" valign="top">&nbsp;:&nbsp;</td><td id="dp_id_u" height="35" align="left" valign="top"></td></tr><tr class="box_text content_wrap1"><td align="left" valign="top" height="35" width="48%">Client ID</td><td align="center" valign="top">&nbsp;:&nbsp;</td><td height="35" id="client_id_u" align="left" valign="top"></td></tr><tr class="box_text content_wrap1"><td align="left" valign="top" height="35" width="48%">Current date</td><td align="center" valign="top">&nbsp;:&nbsp;</td><td id="current_dt_u" align="left" valign="top"></td></tr><tr class="box_text content_wrap1"><td align="left" valign="top" height="40" width="48%">Last Login</td><td align="center" valign="top">&nbsp;:&nbsp;</td><td id="last_login_u" height="35" align="left" valign="top"></td></tr><tr class="box_text content_wrap1"><td align="left" valign="top" height="35" width="48%">Account Status</td><td align="center" valign="top">&nbsp;:&nbsp;</td><td id="account_status_u" height="35" align="left" valign="top"></td></tr></table></div></div></li><div class="scroll_menu"><li class="menu_list soh_details menu_soh" id="mSOH" onclick="soh_details();">Statement of Holding<div id="soh_count" style="display:inline-block;background-color:#4cad50;border-radius:5px;color:#fff;float:right;text-indent:0px;padding:0.2em;"></div></li><li class="menu_list paid_soh menu_portfolio" id="mPortFolio" onclick="paidSOH();">Portfolio</li><li class="menu_list edis menu_e-dis" onclick="edis();">e-DIS Confirmation<div id="edis_count" style="display:inline-block;background-color:#ffc108;border-radius:5px;color:#fff;float:right;text-indent:0px;padding:0.2em;"></div></li><li class="menu_list changed menu_pass" onclick="menu_pass();">Change Password</li><li class="menu_list contact menu_contact" onclick="contact();">Contact Us</li><li class="menu_list logout menu_logout" onclick="logout();">Logout</li><li class="extraMenu_list">&nbsp;&nbsp;</li></div></ul></div><br /><br /></div>');
                  
                  var startX, curX, startY, curY; // Variables
                  var newXScroll, newYScroll, genXScroll; // More Variables!
                  
                  // Change the height of the sidebar, as well as a few things to do with the main content area, so the user
                  // can actually scroll in the content area.
                  function sideBarHeight() {
                  
                  var docHeight = $(document).height();
                  var winHeight = $(window).height();
                  
                  $('.slide-in').height(winHeight);
                  $('#main-container').height(winHeight);
                  $('#sub-container').height($('#sub-container').height());
                  }
                  
                  sideBarHeight();
                  
                  var outIn = 'in';
                  
                  Hammer(document.getElementById('pageone')).on('swiperight', function(e) {
                                                                //localStorage.removeItem('hidemenu');
                                                               // localStorage.removeItem('FreeUser');
                                                                $(".SlideMenu").show();
                                                                $(".overlay_user").show();
                                                                $('.slide-in').toggleClass('on');
                                                                $('.main_wrapper').toggleClass('on');
                                                                outIn = 'out';
                                                                
                                                                });
                  
                  Hammer(document.getElementById('pageone')).on('swipeleft', function(e) {
                                                               // localStorage.removeItem('hidemenu');
                                                               // localStorage.removeItem('FreeUser');
                                                                $(".SlideMenu").hide();
                                                                $(".overlay_user").hide();
                                                                $('.slide-in').toggleClass('on');
                                                                $('.main_wrapper').toggleClass('on');
                                                                outIn = 'in';
                                                                });
                  
                  
                  
                  function runAnimation() {
                  
                  if(outIn == 'out') {
                  
                  $('.slide-in').toggleClass('on');
                  $('#main_wrapper').toggleClass('on');
                  outIn = 'in';
                  
                  } else if(outIn == 'in') {
                  
                  $('.slide-in').toggleClass('on');
                  $('#main_wrapper').toggleClass('on');
                  outIn = 'out';
                  
                  }
                  
                  }
                  
                  
                  $('.menu-icon').click(function() {
                                       // localStorage.removeItem('hidemenu');
                                        //localStorage.removeItem('FreeUser');
                                        $('.slide-in').toggleClass('on');
                                        $('.main_wrapper').toggleClass('on');
                                        $(".SlideMenu").show();
                                        
                                        if($('.slide-in').hasClass('on')){
                                        $(".overlay_user").show();
                                        }
                                        else{
                                        $(".overlay_user").hide();
                                        }
                                        });
                  $(".overlay_user").click(function(){
                                           $(".overlay_user").hide();
                                           $('.slide-in').toggleClass('on');
                                           $('.main_wrapper').toggleClass('on');
                        
                                           });
                  
                  
                  var data = JSON.parse(localStorage.getItem('soh_data'));
                  setInterval('date()', 1000);
                  $("#user_welcome").html(' Welcome ' +JSON.parse(localStorage.getItem('temp_user_name')));
                  $("#dp_id_u").html(JSON.parse(localStorage.getItem('temp_dpid1')));
                  $("#client_id_u").html(JSON.parse(localStorage.getItem('temp_clientId1')));
                  $("#last_login_u").html("<b>"+JSON.parse(localStorage.getItem('temp_last_login'))+"</b>");
                  $("#account_status_u").html(JSON.parse(localStorage.getItem('acc_status')));
                  var ccr_f = JSON.parse(localStorage.getItem('ccrflag'));
                  var mob_f = JSON.parse(localStorage.getItem('mob_flag'));
                  var userType = JSON.parse(localStorage.getItem('userType'));
                  var NYPaidInd = JSON.parse(localStorage.getItem('PaidInd'));
                  var EXPDate = JSON.parse(localStorage.getItem('expiredPortfolio'));
                  if(ccr_f == "Y" && mob_f == "MOB" && userType == "INV")
                  {
                  $("#edis_count").show();
                  console.log("active..");
                  }
                  else
                  {
                  $("#edis_count").hide();
                  $(".edis").css("color" , "#b8b8b8");
                  
                  }
                  if(NYPaidInd == "NP"){
                  document.getElementById('mSOH').style.display = "block";
                  document.getElementById('mPortFolio').style.display = "none";
                  //$("li #mSOH").show();$("li #mPortFolio").hide();
                  }
                  else if(EXPDate == "NExP"){
                  document.getElementById('mPortFolio').style.display = "block";
                  document.getElementById('mSOH').style.display = "none";
                  }
                  else if(EXPDate == "ExP"){
                  $(".paid_soh").css("color" , "#b8b8b8");
                  document.getElementById('mSOH').style.display = "block";
                  document.getElementById('mPortFolio').style.display = "block";
                  }
                  else{
                  console.log("it is paid user.");
                  }
                  //toggle menu
                  $("#soh_count").html(JSON.parse(localStorage.getItem('temp_holding'))+" ISIN's");
                  $("#edis_count").html(JSON.parse(localStorage.getItem('edis_length')) + " Pending");
                  });



