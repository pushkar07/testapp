cordova.define("org.nypr.cordova.hockeyappplugin.HockeyApp", function(require, exports, module) { var exec = require("cordova/exec");

/**
 * This is a global variable called exposed by cordova
 */    
var HockeyApp = function(){};

HockeyApp.prototype.forcecrash = function(success, error) {
  exec(success, error, "HockeyAppPlugin", "forcecrash", []);
};

module.exports = new HockeyApp();

});
